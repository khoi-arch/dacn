#!/usr/bin/env python3
from pathlib import Path
import subprocess
import time
import os
import zipfile

ROOT = Path("/kaggle/working/dacn")
LOG_DIR = ROOT / "03_outputs/parallel_logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

RUNS = [
    {
        "name": "T1_C2_K512_D3LSTM_MHA",
        "device": "cuda:0",
        "dataset_npz": "03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz",
        "metadata_json": "03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_metadata.json",
        "log": LOG_DIR / "T1_C2_K512_D3LSTM_MHA.log",
    },
    {
        "name": "T2_B_K512_D3LSTM_MHA",
        "device": "cuda:1",
        "dataset_npz": "03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only/mixed_quantile_offset_dataset.npz",
        "metadata_json": "03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only/mixed_quantile_offset_metadata.json",
        "log": LOG_DIR / "T2_B_K512_D3LSTM_MHA.log",
    },
]

def check_inputs():
    for r in RUNS:
        for key in ["dataset_npz", "metadata_json"]:
            p = ROOT / r[key]
            if not p.exists():
                raise FileNotFoundError(f"Missing {key} for {r['name']}: {p}")


def command(r):
    return [
        "python", "-u", "02_src/26_train_d3_lstm_mha.py",
        "--run-id", "D3LSTM",
        "--K", "512",
        "--num-bins", "512",
        "--dataset-npz", r["dataset_npz"],
        "--metadata-json", r["metadata_json"],
        "--run-name", r["name"],
        "--epochs", "80",
        "--batch-size", "256",
        "--device", r["device"],
        "--hidden-dim", "128",
        "--num-layers", "2",
        "--num-heads", "4",
        "--dropout", "0.1",
        "--classifier-dropout", "0.1",
    ]

def run_pair():
    check_inputs()
    procs = []
    files = []
    for r in RUNS:
        f = open(r["log"], "w")
        files.append(f)
        p = subprocess.Popen(command(r), cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
        procs.append((r, p))
        print(f"Started {r['name']} PID={p.pid} {r['device']}")

    while True:
        done = True
        print("\n========== STATUS ==========")
        for r, p in procs:
            rc = p.poll()
            print(r["name"], "running" if rc is None else f"done rc={rc}")
            if rc is None:
                done = False
        print("\n========== GPU ==========")
        os.system("nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader")
        for r, p in procs:
            print(f"\n========== {r['name']} last 20 lines ==========")
            os.system(f"tail -20 {r['log']}")
        if done:
            break
        time.sleep(30)

    for f in files:
        f.close()

    failed = [(r["name"], p.returncode) for r, p in procs if p.returncode != 0]
    if failed:
        raise RuntimeError(f"Some runs failed: {failed}")


def zip_outputs():
    out_zip = Path("/kaggle/working/d3_lstm_mha_outputs.zip")
    items = []
    for r in RUNS:
        run_dir = ROOT / "03_outputs/train_runs_fusion_ablation_D0_D7/Keff512" / r["name"]
        for fn in [
            "diagnosis_summary.json",
            "train_classification_report_best.json",
            "val_classification_report_best.json",
            "train_confusion_matrix_best.csv",
            "val_confusion_matrix_best.csv",
            "history.csv",
            "config.json",
            "class_weights.json",
            "val_predictions_best.csv",
        ]:
            items.append(run_dir / fn)
        items.append(r["log"])

    missing = []
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in items:
            if p.exists():
                z.write(p, str(p).replace("/kaggle/working/", ""))
            else:
                missing.append(str(p))
    print("Wrote:", out_zip)
    print("Size:", out_zip.stat().st_size if out_zip.exists() else None)
    if missing:
        print("Missing:")
        for m in missing:
            print(m)
    else:
        print("All files found.")

if __name__ == "__main__":
    run_pair()
    zip_outputs()
