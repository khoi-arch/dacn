#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Run exact cell embedding ablation requested by user.

Architecture per cell:
  X cell = (bin_id, offset)
  bin_id -> nn.Embedding(NUM_BINS, d)
  offset -> Linear(1, d)
  concat -> Linear(2d, d) = v(value)
  feature_embeddings[col] = v(feature)
  cell_token = LayerNorm(v(value) + v(feature))

Runs:
  T1: C2 K512 artifact + D8CELL
  T2: B K512 rank-uniform-all artifact + D8CELL
"""
from __future__ import annotations

import os
import subprocess
import time
import zipfile
from pathlib import Path

ROOT = Path("/kaggle/working/dacn")
SCRIPT = "02_src/23_train_cell_value_feature_add.py"

RUNS = [
    {
        "name": "T1_C2_K512_D8CELL_value_feature_add",
        "dataset": "03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz",
        "metadata": "03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_metadata.json",
        "device": "cuda:0",
        "log": "T1_C2_K512_D8CELL_value_feature_add.log",
    },
    {
        "name": "T2_B_K512_D8CELL_value_feature_add",
        "dataset": "03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only/mixed_quantile_offset_dataset.npz",
        "metadata": "03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only/mixed_quantile_offset_metadata.json",
        "device": "cuda:1",
        "log": "T2_B_K512_D8CELL_value_feature_add.log",
    },
]


def check_inputs() -> None:
    if not (ROOT / SCRIPT).exists():
        raise FileNotFoundError(ROOT / SCRIPT)
    for r in RUNS:
        for k in ["dataset", "metadata"]:
            p = ROOT / r[k]
            if not p.exists():
                raise FileNotFoundError(f"Missing {k} for {r['name']}: {p}")


def launch_pair():
    log_dir = ROOT / "03_outputs/parallel_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    procs = []

    for r in RUNS:
        cmd = [
            "python", "-u", SCRIPT,
            "--run-id", "D8CELL",
            "--K", "512",
            "--num-bins", "512",
            "--dataset-npz", r["dataset"],
            "--metadata-json", r["metadata"],
            "--run-name", r["name"],
            "--epochs", "80",
            "--batch-size", "256",
            "--value-dim", "32",
            "--feature-dim", "32",
            "--device", r["device"],
        ]
        log_path = log_dir / r["log"]
        f = open(log_path, "w")
        p = subprocess.Popen(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
        procs.append((r, p, f, log_path))
        print(f"Started {r['name']} pid={p.pid} device={r['device']} log={log_path}")

    while True:
        print("\n========== STATUS ==========")
        all_done = True
        for r, p, _, log_path in procs:
            rc = p.poll()
            print(r["name"], "running" if rc is None else f"done rc={rc}")
            if rc is None:
                all_done = False

        print("\n========== GPU ==========")
        os.system("nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader")

        for r, _, _, log_path in procs:
            print(f"\n========== {r['name']} last 20 lines ==========")
            os.system(f"tail -20 {log_path}")

        if all_done:
            break
        time.sleep(30)

    for _, _, f, _ in procs:
        f.close()

    bad = [(r["name"], p.returncode) for r, p, _, _ in procs if p.returncode != 0]
    if bad:
        raise RuntimeError(f"Some runs failed: {bad}")


def zip_outputs() -> Path:
    out_zip = Path("/kaggle/working/cell_value_feature_add_D8_outputs.zip")
    log_dir = ROOT / "03_outputs/parallel_logs"
    items = []
    for r in RUNS:
        run_dir = ROOT / "03_outputs/train_runs_fusion_ablation_D0_D7/Keff512" / r["name"]
        for fn in [
            "diagnosis_summary.json",
            "val_classification_report_best.json",
            "val_confusion_matrix_best.csv",
            "history.csv",
            "config.json",
        ]:
            items.append(run_dir / fn)
        items.append(log_dir / r["log"])

    missing = []
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in items:
            if p.exists():
                z.write(p, str(p).replace("/kaggle/working/", ""))
            else:
                missing.append(str(p))

    print("\nWrote:", out_zip)
    print("Size:", out_zip.stat().st_size if out_zip.exists() else None)
    if missing:
        print("\nMissing:")
        for m in missing:
            print(m)
    else:
        print("\nAll files found.")
    return out_zip


def main():
    check_inputs()
    launch_pair()
    zip_outputs()


if __name__ == "__main__":
    main()
