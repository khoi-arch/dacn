# C2 rare-aware keep_current merge ablations

This package tests whether rare/sparse feature-level tokens in C2 keep_current features contribute to overfit.

It uses only train token frequency for feature selection and bin remapping. It does not use validation labels, validation errors, or confusion pairs.

## Scripts

- `02_src/31_build_rare_merge_keepcurrent_artifacts.py`
- `run_4_rare_merge_keepcurrent_kaggle.py`

## Variants

1. `A1`: min_count=20, remap rare bins to nearest stable bin, keep offset.
2. `A2`: min_count=50, remap rare bins to nearest stable bin, keep offset.
3. `A3`: min_count=20, remap rare bins, zero offset for remapped cells.
4. `A4`: min_count=50, remap rare bins, zero offset for remapped cells.

Selected features are keep_current only, chosen by train-only criteria:

- rare_cell_ratio_train(count<=5) >= 0.003, or
- rare_used_bin_ratio_train(count<=5) >= 0.25.

## Expected output

`rare_merge_keepcurrent_outputs.zip`
