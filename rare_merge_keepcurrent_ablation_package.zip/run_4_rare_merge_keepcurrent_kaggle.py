#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kaggle/local runner for C2 rare-aware keep_current merge ablations."""
from __future__ import annotations

import json
import subprocess
import sys
import zipfile
from pathlib import Path


def run(cmd: list[str], cwd: Path) -> None:
    print("\n$", " ".join(map(str, cmd)), flush=True)
    p = subprocess.Popen(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    assert p.stdout is not None
    for line in p.stdout:
        print(line, end="", flush=True)
    code = p.wait()
    if code != 0:
        raise subprocess.CalledProcessError(code, cmd)


def zip_items(zip_path: Path, items: list[Path], root: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in items:
            if not item.exists():
                print(f"[ZIP skip missing] {item}", flush=True)
                continue
            if item.is_file():
                z.write(item, item.relative_to(root).as_posix())
            else:
                for p in item.rglob("*"):
                    if p.is_file():
                        z.write(p, p.relative_to(root).as_posix())
    print(f"[ZIP] {zip_path}", flush=True)


def main() -> None:
    repo = Path.cwd()
    print("[repo]", repo, flush=True)
    build_script = repo / "02_src" / "31_build_rare_merge_keepcurrent_artifacts.py"
    train_script = repo / "02_src" / "10_train_fusion_ablation_D0_D7.py"
    if not build_script.exists():
        raise FileNotFoundError(str(build_script))
    if not train_script.exists():
        raise FileNotFoundError(str(train_script))

    c2_dir = repo / "03_outputs" / "build_mixed_quantile_offset" / "K512_B512_C2_selective_rank_discrete_compact"
    if not c2_dir.exists():
        raise FileNotFoundError(f"Missing C2 artifact dir: {c2_dir}")

    build_variants = [
        # (artifact_dir_name, min_count, offset_mode)
        ("K512_B512_C2_RAREMERGE_keepcurrent_m20_keepoff", 20, "keep"),
        ("K512_B512_C2_RAREMERGE_keepcurrent_m50_keepoff", 50, "keep"),
        ("K512_B512_C2_RAREMERGE_keepcurrent_m20_zerooff", 20, "zero_merged"),
        ("K512_B512_C2_RAREMERGE_keepcurrent_m50_zerooff", 50, "zero_merged"),
    ]

    # 1) Build train-only rare-merge artifacts.
    for name, min_count, offset_mode in build_variants:
        run([
            sys.executable, "-u", str(build_script.relative_to(repo)),
            "--c2-dir", str(c2_dir.relative_to(repo)),
            "--out-root", "03_outputs/build_mixed_quantile_offset",
            "--K", "512",
            "--name", name,
            "--min-count", str(min_count),
            "--offset-mode", offset_mode,
            "--rare-threshold-base", "5",
            "--select-rare-cell-ratio", "0.003",
            "--select-rare-used-ratio", "0.25",
        ], cwd=repo)

    # 2) Train D3 on each artifact.
    out_root = repo / "03_outputs" / "train_runs_rare_merge_keepcurrent"
    out_root.mkdir(parents=True, exist_ok=True)
    summaries = []

    for idx, (name, min_count, offset_mode) in enumerate(build_variants, start=1):
        art_dir = repo / "03_outputs" / "build_mixed_quantile_offset" / name
        run_name = f"A{idx}_{name}_D3"
        run([
            sys.executable, "-u", str(train_script.relative_to(repo)),
            "--run-id", "D3",
            "--K", "512",
            "--num-bins", "512",
            "--dataset-npz", str(art_dir / "mixed_quantile_offset_dataset.npz"),
            "--metadata-json", str(art_dir / "mixed_quantile_offset_metadata.json"),
            "--out-root", str(out_root),
            "--run-name", run_name,
            "--epochs", "80",
            "--patience", "12",
            "--batch-size", "256",
            "--seed", "42",
        ], cwd=repo)
        diag = out_root / "Keff512" / run_name / "diagnosis_summary.json"
        if diag.exists():
            d = json.loads(diag.read_text(encoding="utf-8"))
            summaries.append({
                "run": run_name,
                "artifact": name,
                "min_count": min_count,
                "offset_mode": offset_mode,
                "best_epoch": d.get("best_epoch"),
                "train_macro_f1": d.get("train", {}).get("macro_f1"),
                "val_macro_f1": d.get("val", {}).get("macro_f1"),
                "gap": d.get("generalization_gap_macro_f1"),
                "malware_only_f1": d.get("val", {}).get("malware_only_avg_f1"),
            })

    index_path = repo / "03_outputs" / "rare_merge_keepcurrent_index.json"
    index_path.write_text(json.dumps(summaries, indent=2, ensure_ascii=False), encoding="utf-8")
    print("[SUMMARY]", json.dumps(summaries, indent=2, ensure_ascii=False), flush=True)

    # 3) Zip outputs.
    zip_path = Path("/kaggle/working/rare_merge_keepcurrent_outputs.zip")
    if not Path("/kaggle/working").exists():
        zip_path = repo / "rare_merge_keepcurrent_outputs.zip"
    items = [
        repo / "03_outputs" / "build_mixed_quantile_offset" / name for name, _, _ in build_variants
    ] + [out_root, index_path]
    zip_items(zip_path, items, repo)
    print("\nDONE:", zip_path, flush=True)


if __name__ == "__main__":
    main()
