#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build train-only rare-bin merge artifacts for C2 K512 D3.

Purpose
-------
This ablation tests the hypothesis that a subset of C2 overfit comes from sparse/rare
feature-level tokens in keep_current features.  It does NOT use labels or validation
errors to choose features.  Selection and merge mapping are based only on train token
frequency.

Input
-----
C2 dataset artifact:
  X_train_bin, X_train_offset, y_train, X_val_bin, X_val_offset, y_val
C2 metadata:
  feature_names, feature_strategies

Ablation variants
-----------------
For keep_current features, compute train token counts.  Select a feature if either:
  rare_cell_ratio_le_base >= --select-rare-cell-ratio
  OR rare_used_bin_ratio_le_base >= --select-rare-used-ratio

Then for selected features, map bins whose train count < min_count to the nearest
stable bin with train count >= min_count, by numeric bin id.  This is train-only.

Offset modes:
  keep: keep original offset after bin merge
  zero_merged: set offset=0 only for cells whose bin was remapped

Outputs per variant
-------------------
  mixed_quantile_offset_dataset.npz
  mixed_quantile_offset_metadata.json
  rare_merge_feature_policy.csv
  token_diagnostics_train_before_after.csv
  token_diagnostics_val_before_after.csv
  rare_merge_summary.json
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Any, List, Tuple

import numpy as np
import pandas as pd

STRATEGY_KEEP = "keep_current"
STRATEGY_RANK = "rank_uniform_offset"
STRATEGY_COMPACT = "discrete_compact_offset0"
STRATEGY_CONST = "constant"


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build C2 rare-aware merge ablation artifacts.")
    p.add_argument("--c2-dir", default="03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact")
    p.add_argument("--out-root", default="03_outputs/build_mixed_quantile_offset")
    p.add_argument("--K", type=int, default=512)
    p.add_argument("--min-count", type=int, required=True)
    p.add_argument("--offset-mode", choices=["keep", "zero_merged"], required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--rare-threshold-base", type=int, default=5,
                   help="Base threshold used to select rare-prone features, not necessarily the merge threshold.")
    p.add_argument("--select-rare-cell-ratio", type=float, default=0.003,
                   help="Select keep_current feature if cell exposure to count<=base rare bins exceeds this train-only ratio.")
    p.add_argument("--select-rare-used-ratio", type=float, default=0.25,
                   help="Select keep_current feature if used-bin ratio with count<=base exceeds this train-only ratio.")
    return p.parse_args()


def resolve_path(p: str | Path) -> Path:
    p = Path(p)
    if p.exists():
        return p
    q = repo_root() / p
    if q.exists():
        return q
    raise FileNotFoundError(str(p))


def find_one(base: Path, names: List[str]) -> Path:
    hits: List[Path] = []
    for pat in names:
        hits.extend(sorted(base.glob(pat)))
    hits = [h for h in hits if h.is_file()]
    if not hits:
        raise FileNotFoundError(f"No file in {base} matching {names}")
    return sorted(hits, key=lambda x: (len(x.name), x.name))[0]


def normalize_strategy(s: str) -> str:
    s = str(s).strip()
    low = s.lower()
    if low in {"keep", "keep_current", "current", "uniform", "uniform_offset", "quantile_offset"}:
        return STRATEGY_KEEP
    if low in {"rank", "rank_uniform", "rank_uniform_offset"}:
        return STRATEGY_RANK
    if low in {"compact", "discrete", "discrete_compact", "discrete_compact_offset0"}:
        return STRATEGY_COMPACT
    if low in {"constant", "constant_zero", "zero", "drop"}:
        return STRATEGY_CONST
    return s


def strategy_map_from_metadata(meta: Dict[str, Any], feature_names: List[str]) -> Dict[str, str]:
    obj = meta.get("feature_strategies")
    if isinstance(obj, dict) and all(f in obj for f in feature_names):
        return {f: normalize_strategy(obj[f]) for f in feature_names}
    # Fallback to feature_meta if needed.
    fmap: Dict[str, str] = {}
    for row in meta.get("feature_meta", []):
        if not isinstance(row, dict):
            continue
        f = row.get("feature")
        s = row.get("strategy") or row.get("selected_strategy")
        if f is not None and s is not None:
            fmap[str(f)] = normalize_strategy(str(s))
    if all(f in fmap for f in feature_names):
        return {f: fmap[f] for f in feature_names}
    missing = [f for f in feature_names if f not in fmap]
    raise RuntimeError(f"Cannot recover feature strategy map. Missing: {missing[:20]}")


def entropy_norm_from_counts(counts: np.ndarray) -> float:
    counts = np.asarray(counts, dtype=np.float64)
    counts = counts[counts > 0]
    if counts.size <= 1:
        return 0.0
    p = counts / counts.sum()
    h = float(-(p * np.log(p + 1e-12)).sum())
    return float(h / math.log(counts.size))


def token_diag(feature: str, strategy: str, bins: np.ndarray, offsets: np.ndarray, K: int, split: str, *, train_counts_ref: np.ndarray | None = None) -> Dict[str, Any]:
    b = np.asarray(bins, dtype=np.int64)
    off = np.asarray(offsets, dtype=np.float32)
    counts = np.bincount(np.clip(b, 0, K - 1), minlength=K)
    used = np.flatnonzero(counts > 0)
    used_counts = counts[used]
    rare_used = int((used_counts <= 5).sum()) if used_counts.size else 0
    d: Dict[str, Any] = {
        "feature": feature,
        "split": split,
        "strategy": strategy,
        "K": int(K),
        "bins_used": int(used.size),
        "dominant_bin_ratio": float(used_counts.max() / max(1, b.size)) if used_counts.size else 0.0,
        "entropy_norm": entropy_norm_from_counts(counts),
        "rare_used_bin_ratio_le5": float(rare_used / max(1, used.size)),
        "rare_sample_ratio_le5_own_split": float(np.isin(b, used[used_counts <= 5]).mean()) if used_counts.size else 0.0,
        "offset_nonzero_ratio": float((np.abs(off) > 1e-7).mean()),
        "offset_mean": float(off.mean()) if off.size else 0.0,
        "offset_std": float(off.std()) if off.size else 0.0,
    }
    if train_counts_ref is not None:
        rr = train_counts_ref[np.clip(b, 0, K - 1)] <= 5
        unseen = train_counts_ref[np.clip(b, 0, K - 1)] == 0
        d["rare_cell_ratio_trainref_le5"] = float(rr.mean())
        d["unseen_cell_ratio_trainref"] = float(unseen.mean())
    return d


def nearest_stable_mapping(counts: np.ndarray, min_count: int) -> Tuple[np.ndarray, Dict[str, Any]]:
    K = int(counts.size)
    stable = np.flatnonzero(counts >= int(min_count))
    used = np.flatnonzero(counts > 0)
    mapping = np.arange(K, dtype=np.int64)
    if stable.size == 0:
        return mapping, {
            "stable_bins": 0,
            "used_bins": int(used.size),
            "merged_used_bins": 0,
            "note": "no stable bins; identity mapping",
        }
    # For every bin, map to nearest stable bin by numeric distance.
    # K is small enough for simple search.
    for b in range(K):
        if counts[b] >= int(min_count):
            continue
        pos = np.searchsorted(stable, b)
        candidates = []
        if pos > 0:
            candidates.append(stable[pos - 1])
        if pos < stable.size:
            candidates.append(stable[pos])
        if candidates:
            mapping[b] = int(min(candidates, key=lambda x: (abs(int(x) - b), int(x))))
    merged_used = int(sum(1 for b in used if mapping[b] != b))
    dist = [abs(int(mapping[b]) - int(b)) for b in used if mapping[b] != b]
    return mapping, {
        "stable_bins": int(stable.size),
        "used_bins": int(used.size),
        "merged_used_bins": int(merged_used),
        "merged_used_bin_ratio": float(merged_used / max(1, used.size)),
        "merge_distance_mean_used": float(np.mean(dist)) if dist else 0.0,
        "merge_distance_max_used": int(max(dist)) if dist else 0,
    }


def build_variant(args: argparse.Namespace) -> None:
    c2_dir = resolve_path(args.c2_dir)
    ds_path = find_one(c2_dir, ["mixed_quantile_offset_dataset.npz", "*dataset*.npz"])
    meta_path = find_one(c2_dir, ["mixed_quantile_offset_metadata.json", "*metadata*.json"])
    data = dict(np.load(ds_path, allow_pickle=True))
    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    K = int(args.K)
    feature_names = [str(x) for x in meta["feature_names"]]
    strategy_map = strategy_map_from_metadata(meta, feature_names)

    Xtr_b = data["X_train_bin"].astype(np.int64).copy()
    Xva_b = data["X_val_bin"].astype(np.int64).copy()
    Xtr_o = data["X_train_offset"].astype(np.float32).copy()
    Xva_o = data["X_val_offset"].astype(np.float32).copy()

    before_train_rows: List[Dict[str, Any]] = []
    after_train_rows: List[Dict[str, Any]] = []
    before_val_rows: List[Dict[str, Any]] = []
    after_val_rows: List[Dict[str, Any]] = []
    policy_rows: List[Dict[str, Any]] = []

    for j, f in enumerate(feature_names):
        strat = normalize_strategy(strategy_map[f])
        btr0 = np.clip(Xtr_b[:, j], 0, K - 1)
        bva0 = np.clip(Xva_b[:, j], 0, K - 1)
        otr0 = Xtr_o[:, j].copy()
        ova0 = Xva_o[:, j].copy()
        counts0 = np.bincount(btr0, minlength=K)
        used = np.flatnonzero(counts0 > 0)
        used_counts = counts0[used]
        rare_base_bins = used[used_counts <= int(args.rare_threshold_base)] if used.size else np.array([], dtype=np.int64)
        rare_cell_base = float(np.isin(btr0, rare_base_bins).mean()) if used.size else 0.0
        rare_used_base = float(rare_base_bins.size / max(1, used.size))
        select = (strat == STRATEGY_KEEP) and (
            rare_cell_base >= float(args.select_rare_cell_ratio)
            or rare_used_base >= float(args.select_rare_used_ratio)
        )
        before_train_rows.append(token_diag(f, strat, btr0, otr0, K, "train_before"))
        before_val_rows.append(token_diag(f, strat, bva0, ova0, K, "val_before", train_counts_ref=counts0))

        if select:
            mapping, minfo = nearest_stable_mapping(counts0, int(args.min_count))
            btr1 = mapping[btr0]
            bva1 = mapping[bva0]
            if args.offset_mode == "zero_merged":
                changed_tr = btr1 != btr0
                changed_va = bva1 != bva0
                otr1 = otr0.copy()
                ova1 = ova0.copy()
                otr1[changed_tr] = 0.0
                ova1[changed_va] = 0.0
            else:
                changed_tr = btr1 != btr0
                changed_va = bva1 != bva0
                otr1 = otr0
                ova1 = ova0
            Xtr_b[:, j] = btr1
            Xva_b[:, j] = bva1
            Xtr_o[:, j] = otr1
            Xva_o[:, j] = ova1
            action = "rare_merge"
        else:
            btr1 = btr0
            bva1 = bva0
            otr1 = otr0
            ova1 = ova0
            changed_tr = np.zeros_like(btr0, dtype=bool)
            changed_va = np.zeros_like(bva0, dtype=bool)
            minfo = {"stable_bins": int((counts0 >= int(args.min_count)).sum()), "used_bins": int(used.size), "merged_used_bins": 0}
            action = "unchanged"

        counts1 = np.bincount(np.clip(btr1, 0, K - 1), minlength=K)
        after_train_rows.append(token_diag(f, strat, btr1, otr1, K, "train_after"))
        after_val_rows.append(token_diag(f, strat, bva1, ova1, K, "val_after", train_counts_ref=counts1))
        row = {
            "feature_index": j,
            "feature": f,
            "strategy": strat,
            "selected": bool(select),
            "action": action,
            "min_count": int(args.min_count),
            "offset_mode": str(args.offset_mode),
            "rare_threshold_base": int(args.rare_threshold_base),
            "rare_cell_ratio_base_train": rare_cell_base,
            "rare_used_bin_ratio_base_train": rare_used_base,
            "changed_train_cell_ratio": float(changed_tr.mean()),
            "changed_val_cell_ratio": float(changed_va.mean()),
            **minfo,
        }
        policy_rows.append(row)

    out_dir = Path(args.out_root) / args.name
    out_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        out_dir / "mixed_quantile_offset_dataset.npz",
        X_train_bin=Xtr_b.astype(np.int64),
        X_train_offset=Xtr_o.astype(np.float32),
        y_train=data["y_train"].astype(np.int64),
        X_val_bin=Xva_b.astype(np.int64),
        X_val_offset=Xva_o.astype(np.float32),
        y_val=data["y_val"].astype(np.int64),
    )
    new_meta = dict(meta)
    new_meta["stage"] = "C2_rare_merge_keepcurrent_ablation"
    new_meta["source_c2_dataset"] = str(ds_path)
    new_meta["source_c2_metadata"] = str(meta_path)
    new_meta["rare_merge"] = {
        "name": args.name,
        "K": K,
        "min_count": int(args.min_count),
        "offset_mode": str(args.offset_mode),
        "rare_threshold_base": int(args.rare_threshold_base),
        "select_rare_cell_ratio": float(args.select_rare_cell_ratio),
        "select_rare_used_ratio": float(args.select_rare_used_ratio),
        "selection_uses_labels": False,
        "selection_uses_val_errors": False,
        "selection_basis": "train token counts only, keep_current features only",
    }
    # Preserve input metadata so D3 can load raw_scaled as before.
    new_meta["outputs"] = {
        "dataset_npz": str(out_dir / "mixed_quantile_offset_dataset.npz"),
        "metadata_json": str(out_dir / "mixed_quantile_offset_metadata.json"),
    }
    Path(out_dir / "mixed_quantile_offset_metadata.json").write_text(json.dumps(new_meta, indent=2, ensure_ascii=False), encoding="utf-8")

    pd.DataFrame(policy_rows).to_csv(out_dir / "rare_merge_feature_policy.csv", index=False)
    pd.concat([pd.DataFrame(before_train_rows), pd.DataFrame(after_train_rows)], ignore_index=True).to_csv(out_dir / "token_diagnostics_train_before_after.csv", index=False)
    pd.concat([pd.DataFrame(before_val_rows), pd.DataFrame(after_val_rows)], ignore_index=True).to_csv(out_dir / "token_diagnostics_val_before_after.csv", index=False)

    pol = pd.DataFrame(policy_rows)
    summary = {
        "name": args.name,
        "K": K,
        "min_count": int(args.min_count),
        "offset_mode": str(args.offset_mode),
        "n_features": int(len(feature_names)),
        "selected_features": int(pol["selected"].sum()),
        "selected_feature_names": pol.loc[pol["selected"], "feature"].tolist(),
        "mean_changed_train_cell_ratio_selected": float(pol.loc[pol["selected"], "changed_train_cell_ratio"].mean()) if int(pol["selected"].sum()) else 0.0,
        "mean_changed_val_cell_ratio_selected": float(pol.loc[pol["selected"], "changed_val_cell_ratio"].mean()) if int(pol["selected"].sum()) else 0.0,
        "output_dir": str(out_dir),
    }
    (out_dir / "rare_merge_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)


def main() -> None:
    args = parse_args()
    build_variant(args)


if __name__ == "__main__":
    main()
