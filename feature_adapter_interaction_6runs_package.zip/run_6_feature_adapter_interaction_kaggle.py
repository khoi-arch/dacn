#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run 6 feature-adapter / relation-interaction ablations in 3 rounds on 2 GPUs.

All runs keep C2/B token artifacts and D3 raw FiLM. The only changes are:
  - D3FA: shared bin embedding + low-rank feature-token adapter
  - D3FAMIX: D3FA + learned feature-relation mixer before Transformer
  - D3FAMIXREG: D3FAMIX + stronger regularization/dropout/wd
"""
from pathlib import Path
import subprocess
import time
import os
import zipfile

ROOT = Path('/kaggle/working/dacn')
SCRIPT = ROOT / '02_src/22_train_feature_adapter_interaction_ablation.py'
LOG_DIR = ROOT / '03_outputs/parallel_logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)

C2_NPZ = '03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz'
C2_META = '03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_metadata.json'
B_NPZ = '03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only/mixed_quantile_offset_dataset.npz'
B_META = '03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only/mixed_quantile_offset_metadata.json'

for p in [ROOT / C2_NPZ, ROOT / C2_META, ROOT / B_NPZ, ROOT / B_META, SCRIPT]:
    if not p.exists():
        raise FileNotFoundError(p)

BASE = [
    'python', '-u', str(SCRIPT),
    '--K', '512',
    '--num-bins', '512',
    '--epochs', '80',
    '--batch-size', '256',
    '--patience', '12',
]

def cmd(run_id, run_name, dataset, meta, device, extra):
    return BASE + [
        '--run-id', run_id,
        '--run-name', run_name,
        '--dataset-npz', dataset,
        '--metadata-json', meta,
        '--device', device,
    ] + extra

RUNS = [
    # Round 1: C2 best tokenization. Adapter only vs adapter+relation.
    {
        'name': 'A1_C2_K512_D3FA_adapter_rank4_a005',
        'cmd': cmd('D3FA', 'A1_C2_K512_D3FA_adapter_rank4_a005', C2_NPZ, C2_META, 'cuda:0', [
            '--feature-adapter-rank', '4',
            '--feature-adapter-alpha', '0.05',
            '--feature-adapter-dropout', '0.0',
        ]),
    },
    {
        'name': 'A2_C2_K512_D3FAMIX_rank4_a005_rel005',
        'cmd': cmd('D3FAMIX', 'A2_C2_K512_D3FAMIX_rank4_a005_rel005', C2_NPZ, C2_META, 'cuda:1', [
            '--feature-adapter-rank', '4',
            '--feature-adapter-alpha', '0.05',
            '--feature-adapter-dropout', '0.0',
            '--relation-mix-alpha', '0.05',
            '--relation-init-diag', '2.0',
        ]),
    },
    # Round 2: B rank-all tokenization. Same split to see if adapter helps when tokens are more uniform.
    {
        'name': 'A3_B_K512_D3FA_adapter_rank4_a005',
        'cmd': cmd('D3FA', 'A3_B_K512_D3FA_adapter_rank4_a005', B_NPZ, B_META, 'cuda:0', [
            '--feature-adapter-rank', '4',
            '--feature-adapter-alpha', '0.05',
            '--feature-adapter-dropout', '0.0',
        ]),
    },
    {
        'name': 'A4_B_K512_D3FAMIX_rank4_a005_rel005',
        'cmd': cmd('D3FAMIX', 'A4_B_K512_D3FAMIX_rank4_a005_rel005', B_NPZ, B_META, 'cuda:1', [
            '--feature-adapter-rank', '4',
            '--feature-adapter-alpha', '0.05',
            '--feature-adapter-dropout', '0.0',
            '--relation-mix-alpha', '0.05',
            '--relation-init-diag', '2.0',
        ]),
    },
    # Round 3: regularized relation variants on C2 only.
    {
        'name': 'A5_C2_K512_D3FAMIXREG_rank4_a010_rel005_do005_wd3e4',
        'cmd': cmd('D3FAMIXREG', 'A5_C2_K512_D3FAMIXREG_rank4_a010_rel005_do005_wd3e4', C2_NPZ, C2_META, 'cuda:0', [
            '--feature-adapter-rank', '4',
            '--feature-adapter-alpha', '0.10',
            '--feature-adapter-dropout', '0.05',
            '--relation-mix-alpha', '0.05',
            '--relation-mix-dropout', '0.05',
            '--relation-init-diag', '2.0',
            '--weight-decay', '3e-4',
        ]),
    },
    {
        'name': 'A6_C2_K512_D3FAMIXREG_rank2_a005_rel003_do005_wd3e4',
        'cmd': cmd('D3FAMIXREG', 'A6_C2_K512_D3FAMIXREG_rank2_a005_rel003_do005_wd3e4', C2_NPZ, C2_META, 'cuda:1', [
            '--feature-adapter-rank', '2',
            '--feature-adapter-alpha', '0.05',
            '--feature-adapter-dropout', '0.05',
            '--relation-mix-alpha', '0.03',
            '--relation-mix-dropout', '0.05',
            '--relation-init-diag', '2.5',
            '--weight-decay', '3e-4',
        ]),
    },
]

rounds = [(RUNS[0], RUNS[1]), (RUNS[2], RUNS[3]), (RUNS[4], RUNS[5])]

for ridx, pair in enumerate(rounds, start=1):
    print(f"\n================ ROUND {ridx}/3 ================")
    procs = []
    for r in pair:
        log_path = LOG_DIR / f"{r['name']}.log"
        print('Starting:', r['name'])
        print('Log:', log_path)
        f = open(log_path, 'w')
        p = subprocess.Popen(r['cmd'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
        procs.append((r, p, f, log_path))

    while True:
        all_done = True
        print('\n========== STATUS ==========')
        for r, p, f, log_path in procs:
            rc = p.poll()
            print(r['name'], 'running' if rc is None else f'done rc={rc}')
            all_done = all_done and (rc is not None)

        print('\n========== GPU ==========')
        os.system('nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader')

        for r, p, f, log_path in procs:
            print(f"\n========== {r['name']} last 18 lines ==========")
            os.system(f"tail -18 {log_path}")

        if all_done:
            break
        time.sleep(30)

    for r, p, f, log_path in procs:
        f.close()
        if p.returncode != 0:
            raise RuntimeError(f"Run failed: {r['name']} rc={p.returncode}. Check {log_path}")

print('\nAll runs completed. Zipping outputs...')

items = []
for r in RUNS:
    run_dir = ROOT / '03_outputs/train_runs_fusion_ablation_D0_D7/Keff512' / r['name']
    for fn in [
        'diagnosis_summary.json',
        'val_classification_report_best.json',
        'val_confusion_matrix_best.csv',
        'history.csv',
        'config.json',
    ]:
        items.append(run_dir / fn)
    items.append(LOG_DIR / f"{r['name']}.log")

out_zip = Path('/kaggle/working/feature_adapter_interaction_6runs_outputs.zip')
missing = []
with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in items:
        p = Path(p)
        if p.exists():
            z.write(p, str(p).replace('/kaggle/working/', ''))
        else:
            missing.append(str(p))

print('Wrote:', out_zip)
print('Size:', out_zip.stat().st_size if out_zip.exists() else None)
if missing:
    print('\nMissing:')
    for m in missing:
        print(m)
else:
    print('\nAll files found.')
