# D3S2R: D3 + feature-bin residual + width-aware smoothness

This package adds a new training script:

```bash
02_src/19_train_D3S2R.py
```

It keeps D3 intact:
- bin + offset interpolation
- raw_scaled FiLM branch
- feature embedding concat
- Transformer classifier

It adds:
- feature-bin residual: `E(f,k) = E_shared(k) + alpha * mask(f) * R(f,k)`
- width-aware smoothness: narrow empirical bins are smoothed more, wide bins less
- residual mask: only features with positive smoothness lambda get residual capacity

Recommended first two runs:

```bash
# D3S2R-a: only rank_uniform group gets feature-bin residual + smoothness
python -u 02_src/19_train_D3S2R.py \
  --run-id D3S2R \
  --K 512 --num-bins 512 \
  --dataset-npz 03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz \
  --metadata-json 03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_metadata.json \
  --run-name D3S2R_P1_K512_C2_rank_only_alpha010_lam1e3 \
  --epochs 80 --batch-size 256 \
  --d3s2r-residual-alpha 0.10 \
  --d3s2r-lambda-rank 1e-3 \
  --d3s2r-lambda-current 0 \
  --d3s2r-lambda-compact 0 \
  --d3s2r-width-space signed_log1p

# D3S2R-b: rank group + very light keep_current regularization
python -u 02_src/19_train_D3S2R.py \
  --run-id D3S2R \
  --K 512 --num-bins 512 \
  --dataset-npz 03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz \
  --metadata-json 03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_metadata.json \
  --run-name D3S2R_P1_K512_C2_rank_current_alpha010_lam1e3_1e4 \
  --epochs 80 --batch-size 256 \
  --d3s2r-residual-alpha 0.10 \
  --d3s2r-lambda-rank 1e-3 \
  --d3s2r-lambda-current 1e-4 \
  --d3s2r-lambda-compact 0 \
  --d3s2r-width-space signed_log1p
```

Outputs include:
- `history.csv` with `train_step_ce_loss` and `train_step_smooth_loss`
- `d3s2r_width_weight_summary.csv`
- `d3s2r_smooth_coeff.npy`
- `diagnosis_summary.json` with D3S2R config and residual diagnostics
