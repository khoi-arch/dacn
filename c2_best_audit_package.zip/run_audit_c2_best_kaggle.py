#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pathlib import Path
import subprocess, sys

ROOT = Path('/kaggle/working/dacn') if Path('/kaggle/working/dacn').exists() else Path.cwd()
cmd = [
    sys.executable, '-u', str(ROOT / '02_src' / '28_audit_c2_best.py'),
    '--out-dir', str(ROOT / '03_outputs' / 'audit_c2_best'),
    '--device', 'auto',
    '--batch-size', '512',
    '--rare-threshold', '5',
]
print('Running:', ' '.join(cmd))
subprocess.run(cmd, cwd=str(ROOT), check=True)
