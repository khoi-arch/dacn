# C2 D3 regularization ablation

This package does not change tokenization, embedding type, raw FiLM, or Transformer CLS.
It only varies training regularization knobs exposed by `02_src/10_train_fusion_ablation_D0_D7.py`.

Runs:
- R1 dropout 0.15 / classifier dropout 0.15
- R2 dropout 0.20 / classifier dropout 0.20
- R3 weight decay 3e-4
- R4 weight decay 1e-3
- R5 lr 5e-4 + wd 3e-4 + dropout 0.15
- R6 no class weights control

Output:
`/kaggle/working/c2_regularization_ablation_outputs.zip`
