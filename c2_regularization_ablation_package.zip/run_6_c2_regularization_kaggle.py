#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run C2 D3 training/regularization ablations without changing tokenization/model family.

This runner intentionally keeps the C2 K512 artifact and D3 embedding/backbone fixed.
It only varies training regularization knobs exposed by 10_train_fusion_ablation_D0_D7.py.
"""
from __future__ import annotations

import json
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any


def run(cmd: list[str], cwd: Path) -> None:
    print("\n$", " ".join(map(str, cmd)), flush=True)
    p = subprocess.Popen(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    assert p.stdout is not None
    for line in p.stdout:
        print(line, end="", flush=True)
    code = p.wait()
    if code != 0:
        raise subprocess.CalledProcessError(code, cmd)


def zip_items(zip_path: Path, items: list[Path], root: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in items:
            if not item.exists():
                print(f"[ZIP skip missing] {item}", flush=True)
                continue
            if item.is_file():
                z.write(item, item.relative_to(root).as_posix())
            else:
                for p in item.rglob("*"):
                    if p.is_file():
                        z.write(p, p.relative_to(root).as_posix())
    print(f"[ZIP] {zip_path}", flush=True)


def load_diag(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text())
    except Exception as e:
        return {"error": str(e), "path": str(path)}


def metric_row(run_name: str, run_dir: Path, extra: dict[str, Any]) -> dict[str, Any]:
    diag = load_diag(run_dir / "diagnosis_summary.json")
    row: dict[str, Any] = {"run": run_name, **extra}
    if "error" in diag:
        row["error"] = diag["error"]
        return row
    row.update({
        "best_epoch": diag.get("best_epoch"),
        "train_macro_f1": diag.get("train", {}).get("macro_f1"),
        "val_macro_f1": diag.get("val", {}).get("macro_f1"),
        "gap_macro_f1": diag.get("generalization_gap_macro_f1"),
        "val_acc": diag.get("val", {}).get("accuracy"),
        "val_weighted_f1": diag.get("val", {}).get("weighted_f1"),
        "val_malware_only_f1": diag.get("val", {}).get("malware_only_avg_f1"),
        "val_loss": diag.get("val", {}).get("loss"),
    })
    return row


def main() -> None:
    repo = Path.cwd()
    print("[repo]", repo, flush=True)

    train_script = repo / "02_src" / "10_train_fusion_ablation_D0_D7.py"
    if not train_script.exists():
        raise FileNotFoundError(f"Missing train script: {train_script}")

    c2_dir = repo / "03_outputs" / "build_mixed_quantile_offset" / "K512_B512_C2_selective_rank_discrete_compact"
    dataset = c2_dir / "mixed_quantile_offset_dataset.npz"
    metadata = c2_dir / "mixed_quantile_offset_metadata.json"
    if not dataset.exists():
        raise FileNotFoundError(f"Missing C2 dataset: {dataset}")
    if not metadata.exists():
        raise FileNotFoundError(f"Missing C2 metadata: {metadata}")

    out_root = repo / "03_outputs" / "train_runs_c2_regularization_ablation"
    out_root.mkdir(parents=True, exist_ok=True)

    # Keep tokenization + D3 architecture fixed. Only regularization/training knobs change.
    # Baseline reference: dropout=0.1, classifier_dropout=0.1, wd=1e-4, lr=1e-3, class weights on.
    specs = [
        {
            "run_name": "R1_C2_D3_drop015_cls015_wd1e4",
            "dropout": 0.15, "classifier_dropout": 0.15, "lr": 1e-3, "wd": 1e-4,
            "class_weights": True,
            "note": "slightly stronger dropout only",
        },
        {
            "run_name": "R2_C2_D3_drop020_cls020_wd1e4",
            "dropout": 0.20, "classifier_dropout": 0.20, "lr": 1e-3, "wd": 1e-4,
            "class_weights": True,
            "note": "stronger dropout only",
        },
        {
            "run_name": "R3_C2_D3_drop010_cls010_wd3e4",
            "dropout": 0.10, "classifier_dropout": 0.10, "lr": 1e-3, "wd": 3e-4,
            "class_weights": True,
            "note": "weight decay 3e-4",
        },
        {
            "run_name": "R4_C2_D3_drop010_cls010_wd1e3",
            "dropout": 0.10, "classifier_dropout": 0.10, "lr": 1e-3, "wd": 1e-3,
            "class_weights": True,
            "note": "weight decay 1e-3",
        },
        {
            "run_name": "R5_C2_D3_drop015_cls015_lr5e4_wd3e4",
            "dropout": 0.15, "classifier_dropout": 0.15, "lr": 5e-4, "wd": 3e-4,
            "class_weights": True,
            "note": "lower lr + modest dropout + wd",
        },
        {
            "run_name": "R6_C2_D3_drop010_cls010_wd1e4_nocw",
            "dropout": 0.10, "classifier_dropout": 0.10, "lr": 1e-3, "wd": 1e-4,
            "class_weights": False,
            "note": "remove class weights control",
        },
    ]

    rows = []
    for i, spec in enumerate(specs, 1):
        cmd = [
            sys.executable, "-u", str(train_script.relative_to(repo)),
            "--run-id", "D3",
            "--K", "512",
            "--num-bins", "512",
            "--dataset-npz", str(dataset),
            "--metadata-json", str(metadata),
            "--out-root", str(out_root),
            "--run-name", spec["run_name"],
            "--epochs", "80",
            "--patience", "12",
            "--batch-size", "256",
            "--seed", "42",
            "--lr", str(spec["lr"]),
            "--weight-decay", str(spec["wd"]),
            "--scheduler", "warmup_cosine",
            "--warmup-epochs", "8",
            "--dropout", str(spec["dropout"]),
            "--classifier-dropout", str(spec["classifier_dropout"]),
        ]
        if spec["class_weights"]:
            cmd.append("--use-class-weights")
        else:
            cmd.append("--no-use-class-weights")
        run(cmd, cwd=repo)

        run_dir = out_root / "Keff512" / spec["run_name"]
        rows.append(metric_row(spec["run_name"], run_dir, {
            "dropout": spec["dropout"],
            "classifier_dropout": spec["classifier_dropout"],
            "lr": spec["lr"],
            "weight_decay": spec["wd"],
            "class_weights": spec["class_weights"],
            "note": spec["note"],
        }))

    summary_dir = repo / "03_outputs" / "c2_regularization_ablation_summary"
    summary_dir.mkdir(parents=True, exist_ok=True)
    (summary_dir / "summary.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False))

    # Write CSV without pandas dependency.
    import csv
    cols = sorted({k for row in rows for k in row.keys()})
    with (summary_dir / "summary.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)

    # Markdown mini summary.
    best = sorted([r for r in rows if r.get("val_macro_f1") is not None], key=lambda r: r["val_macro_f1"], reverse=True)
    lines = ["# C2 D3 regularization ablation", "", "Baseline reference: C2 D3 old val macro-F1 = 0.817147.", ""]
    if best:
        lines.append(f"Best new run: `{best[0]['run']}` val_macro_f1={best[0]['val_macro_f1']}")
    lines.append("")
    lines.append("| run | val_macro_f1 | train_macro_f1 | gap | malware_only | note |")
    lines.append("|---|---:|---:|---:|---:|---|")
    for r in best:
        lines.append(f"| {r.get('run')} | {r.get('val_macro_f1')} | {r.get('train_macro_f1')} | {r.get('gap_macro_f1')} | {r.get('val_malware_only_f1')} | {r.get('note')} |")
    (summary_dir / "summary.md").write_text("\n".join(lines))

    zip_path = Path("/kaggle/working/c2_regularization_ablation_outputs.zip") if Path("/kaggle/working").exists() else repo / "c2_regularization_ablation_outputs.zip"
    items = [out_root, summary_dir]
    # Include C2 baseline run if present for comparison.
    c2_run_dir = repo / "03_outputs" / "train_runs_fusion_ablation_D0_D7" / "Keff512" / "D3_P1_K512_B512_C2_selective_rank_discrete_compact"
    if c2_run_dir.exists():
        items.append(c2_run_dir / "diagnosis_summary.json")
        items.append(c2_run_dir / "history.csv")
        items.append(c2_run_dir / "val_classification_report_best.json")
        items.append(c2_run_dir / "val_confusion_matrix_best.csv")
    zip_items(zip_path, items, repo)
    print(zip_path, flush=True)


if __name__ == "__main__":
    main()
