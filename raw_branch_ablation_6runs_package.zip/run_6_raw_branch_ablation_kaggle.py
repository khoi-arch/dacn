#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run 6 raw continuous branch ablations in 3 two-GPU rounds.

All runs keep C2 K512 tokenization + D3 shared embedding + offset + raw FiLM.
Only the continuous value passed to FiLM changes via --raw-transform.
"""
from __future__ import annotations

import os
import subprocess
import time
import zipfile
from pathlib import Path

ROOT = Path('/kaggle/working/dacn')
SCRIPT = ROOT / '02_src/21_train_raw_branch_ablation.py'
LOG_DIR = ROOT / '03_outputs/parallel_logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)

DATASET_NPZ = '03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz'
METADATA_JSON = '03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_metadata.json'

REQUIRED = [
    ROOT / DATASET_NPZ,
    ROOT / METADATA_JSON,
    SCRIPT,
]
for p in REQUIRED:
    if not p.exists():
        raise FileNotFoundError(p)

BASE_ARGS = [
    'python', '-u', str(SCRIPT.relative_to(ROOT)),
    '--run-id', 'D3',
    '--K', '512',
    '--num-bins', '512',
    '--dataset-npz', DATASET_NPZ,
    '--metadata-json', METADATA_JSON,
    '--epochs', '80',
    '--batch-size', '256',
]

RUNS = [
    {
        'name': 'R1_C2_D3_raw_linear_minmax_control',
        'raw_transform': 'linear_minmax',
        'device': 'cuda:0',
        'tag': 'control',
    },
    {
        'name': 'R2_C2_D3_raw_signed_log1p_minmax',
        'raw_transform': 'signed_log1p_minmax',
        'device': 'cuda:1',
        'tag': 'tail_log',
    },
    {
        'name': 'R3_C2_D3_raw_qclip_001_999_minmax',
        'raw_transform': 'qclip_001_999_minmax',
        'device': 'cuda:0',
        'tag': 'tail_clip',
    },
    {
        'name': 'R4_C2_D3_raw_rank_uniform',
        'raw_transform': 'rank_uniform',
        'device': 'cuda:1',
        'tag': 'rank_only',
    },
    {
        'name': 'R5_C2_D3_raw_blend_linear_rank_050',
        'raw_transform': 'blend_linear_rank_050',
        'device': 'cuda:0',
        'tag': 'linear_rank_blend',
    },
    {
        'name': 'R6_C2_D3_raw_blend_log_rank_050',
        'raw_transform': 'blend_log_rank_050',
        'device': 'cuda:1',
        'tag': 'log_rank_blend',
    },
]

ROUNDS = [RUNS[0:2], RUNS[2:4], RUNS[4:6]]


def run_round(round_idx: int, runs: list[dict]) -> None:
    print(f"\n================ ROUND {round_idx} ================")
    procs = []
    logs = []
    for r in runs:
        log_path = LOG_DIR / f"{r['name']}.log"
        cmd = BASE_ARGS + [
            '--run-name', r['name'],
            '--raw-transform', r['raw_transform'],
            '--device', r['device'],
        ]
        print('Starting:', r['name'])
        print('CMD:', ' '.join(cmd))
        f = open(log_path, 'w')
        p = subprocess.Popen(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
        procs.append((p, f, r))
        logs.append(log_path)
        print('PID:', p.pid, 'device:', r['device'], 'log:', log_path)

    while True:
        all_done = True
        print(f"\n========== ROUND {round_idx} STATUS ==========")
        for p, _f, r in procs:
            rc = p.poll()
            print(r['name'], 'running' if rc is None else f'done rc={rc}')
            if rc is None:
                all_done = False

        print("\n========== GPU ==========")
        os.system('nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader')

        for log_path in logs:
            print(f"\n========== tail {log_path.name} ==========")
            os.system(f'tail -20 {log_path}')

        if all_done:
            break
        time.sleep(30)

    failed = []
    for p, f, r in procs:
        f.close()
        if p.returncode != 0:
            failed.append((r['name'], p.returncode))
    if failed:
        raise RuntimeError(f'Round {round_idx} failed: {failed}')


def collect_outputs() -> Path:
    out_zip = Path('/kaggle/working/raw_branch_ablation_6runs_outputs.zip')
    items = []
    for r in RUNS:
        run_dir = ROOT / '03_outputs/train_runs_fusion_ablation_D0_D7/Keff512' / r['name']
        for fname in [
            'diagnosis_summary.json',
            'val_classification_report_best.json',
            'val_confusion_matrix_best.csv',
            'history.csv',
            'config.json',
        ]:
            items.append(run_dir / fname)
        items.append(LOG_DIR / f"{r['name']}.log")

    missing = []
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in items:
            if p.exists():
                z.write(p, str(p).replace('/kaggle/working/', ''))
            else:
                missing.append(str(p))

    print('\nWrote:', out_zip)
    print('Size:', out_zip.stat().st_size if out_zip.exists() else None)
    if missing:
        print('\nMissing files:')
        for m in missing:
            print(m)
    else:
        print('\nAll files found.')
    return out_zip


def main() -> None:
    print('ROOT:', ROOT)
    print('SCRIPT:', SCRIPT)
    print('Dataset:', ROOT / DATASET_NPZ)
    print('Metadata:', ROOT / METADATA_JSON)
    for idx, runs in enumerate(ROUNDS, start=1):
        run_round(idx, runs)
    collect_outputs()


if __name__ == '__main__':
    main()
