#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build corrected K=1024 artifacts for C2 policy.

Purpose
-------
This script specifically audits and fixes the earlier K1024 C4a/C4b failure modes:

1) No mixed K-space: every feature is regenerated natively with K=1024.
   No keep_current feature is left in a 0..511 token coordinate while model uses 1024 bins.

2) Rank-safe mapping uses pos = rank/(n_unique-1) * (K-1), not *K.
   This avoids the exact alias where n_unique-1 divides K and every position lands on integer even bins.

3) Detailed token diagnostics are exported for K1024 and, when possible, compared to the C2 K512 artifact.

Outputs
-------
For each variant:
  mixed_quantile_offset_dataset.npz
  mixed_quantile_offset_metadata.json
  tokenization_diagnostics_train.csv
  tokenization_diagnostics_val.csv
  rank_mapping_diagnostics.csv
  c2_vs_k1024_tokenization_train.csv  (if C2 artifact is available)
  global_tokenization_summary.json

Variants
--------
rank_safe:
  C2 policy preserved. rank_uniform_offset features are regenerated with corrected rank mapping.

abs_for_rank_control:
  Same as above, except rank_uniform_offset features use absolute train-minmax uniform K1024.
  This isolates whether rank-space, not K1024 itself, is hurting absolute numeric geometry.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np
import pandas as pd


STRATEGY_RANK = "rank_uniform_offset"
STRATEGY_COMPACT = "discrete_compact_offset0"
STRATEGY_KEEP = "keep_current"
STRATEGY_CONST = "constant"


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build corrected K1024 C2-policy token artifacts with diagnostics.")
    p.add_argument("--K", type=int, default=1024)
    p.add_argument("--c2-dir", default="03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact")
    p.add_argument("--train-raw", default="01_split/train_raw.csv")
    p.add_argument("--val-raw", default="01_split/val_raw.csv")
    p.add_argument("--out-root", default="03_outputs/build_mixed_quantile_offset")
    p.add_argument("--variants", nargs="+", default=["rank_safe", "abs_for_rank_control"], choices=["rank_safe", "abs_for_rank_control"])
    p.add_argument("--label-col", default="", help="Optional label column override; normally labels are reused from C2 npz.")
    return p.parse_args()


def resolve_path(p: str | Path) -> Path:
    p = Path(p)
    if p.exists():
        return p
    rp = repo_root() / p
    if rp.exists():
        return rp
    raise FileNotFoundError(str(p))


def find_one(base: Path, patterns: List[str]) -> Path:
    hits: List[Path] = []
    for pat in patterns:
        hits.extend(sorted(base.glob(pat)))
    hits = [h for h in hits if h.is_file()]
    if not hits:
        raise FileNotFoundError(f"No file in {base} matching {patterns}")
    # Prefer non-backup and canonical names.
    hits = sorted(hits, key=lambda x: (len(x.name), x.name))
    return hits[0]


def load_c2(c2_dir: Path) -> Tuple[Dict[str, np.ndarray], Dict[str, Any], Path, Path]:
    ds_path = find_one(c2_dir, ["*dataset*.npz", "mixed_quantile_offset_dataset.npz"])
    meta_path = find_one(c2_dir, ["*metadata*.json", "mixed_quantile_offset_metadata.json"])
    data = dict(np.load(ds_path, allow_pickle=True))
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    return data, meta, ds_path, meta_path


def normalize_strategy(s: str) -> str:
    s0 = str(s).strip()
    low = s0.lower()
    if low in {"rank", "rank_uniform", "rank_uniform_offset", "rank_uniform_offset0"}:
        return STRATEGY_RANK
    if low in {"discrete", "compact", "discrete_compact", "discrete_compact_offset0", "compact_offset0"}:
        return STRATEGY_COMPACT
    if low in {"constant", "constant_zero", "drop", "zero"}:
        return STRATEGY_CONST
    if low in {"keep", "keep_current", "current", "uniform", "uniform_offset", "quantile_offset", "minmax", "current_mixed"}:
        return STRATEGY_KEEP
    return s0


def extract_strategy_from_obj(obj: Any, feature_names: List[str]) -> Dict[str, str] | None:
    # Dict: feature -> strategy or feature -> dict(strategy=...)
    if isinstance(obj, dict):
        if all(f in obj for f in feature_names):
            out: Dict[str, str] = {}
            ok = True
            for f in feature_names:
                v = obj[f]
                if isinstance(v, dict):
                    sv = v.get("strategy", v.get("selected_strategy", v.get("action", v.get("c2_strategy"))))
                else:
                    sv = v
                if sv is None:
                    ok = False
                    break
                out[f] = normalize_strategy(str(sv))
            if ok:
                return out
        # Dict containing useful nested values
        for key in ["feature_policy", "policy_by_feature", "strategy_by_feature", "feature_strategies", "strategies"]:
            if key in obj:
                got = extract_strategy_from_obj(obj[key], feature_names)
                if got is not None:
                    return got
    # List of dicts
    if isinstance(obj, list):
        out: Dict[str, str] = {}
        for row in obj:
            if not isinstance(row, dict):
                continue
            f = row.get("feature", row.get("feature_name", row.get("name", row.get("column"))))
            sv = row.get("strategy", row.get("selected_strategy", row.get("action", row.get("c2_strategy"))))
            if f is not None and sv is not None:
                out[str(f)] = normalize_strategy(str(sv))
        if all(f in out for f in feature_names):
            return {f: out[f] for f in feature_names}
    return None


def extract_strategy_from_csvs(c2_dir: Path, feature_names: List[str]) -> Dict[str, str] | None:
    csvs = sorted(c2_dir.glob("*.csv"))
    # Prefer files with policy/strategy/diag in name.
    csvs = sorted(csvs, key=lambda p: (0 if any(k in p.name.lower() for k in ["policy", "strategy", "diag", "selection"]) else 1, p.name))
    feature_cols = ["feature", "feature_name", "name", "column"]
    strategy_cols = ["strategy", "selected_strategy", "c2_strategy", "final_strategy", "action", "selected_action"]
    for csv in csvs:
        try:
            df = pd.read_csv(csv)
        except Exception:
            continue
        fcol = next((c for c in feature_cols if c in df.columns), None)
        scol = next((c for c in strategy_cols if c in df.columns), None)
        if fcol is None or scol is None:
            continue
        mp: Dict[str, str] = {}
        for _, r in df.iterrows():
            f = str(r[fcol])
            if f in feature_names:
                mp[f] = normalize_strategy(str(r[scol]))
        if all(f in mp for f in feature_names):
            print(f"[strategy] loaded from CSV: {csv}")
            return {f: mp[f] for f in feature_names}
    return None


def get_strategy_map(c2_dir: Path, c2_meta: Dict[str, Any], feature_names: List[str]) -> Dict[str, str]:
    got = extract_strategy_from_obj(c2_meta, feature_names)
    if got is not None:
        print("[strategy] loaded from C2 metadata")
        return got
    got = extract_strategy_from_csvs(c2_dir, feature_names)
    if got is not None:
        return got

    # Last resort: infer compact/constant from C2 arrays and keep the rest as keep_current.
    # This is intentionally conservative and prints a warning; rank group cannot be recovered perfectly.
    print("[WARN] Could not find explicit C2 strategy map in metadata/CSV.")
    print("[WARN] Falling back to a conservative inferred map: constants/compact from raw unique; other features keep_current.")
    raise RuntimeError(
        "Cannot safely preserve C2 policy because per-feature strategy was not found. "
        "Please check C2 metadata/CSV. Expected values like rank_uniform_offset, discrete_compact_offset0, keep_current, constant."
    )


def safe_numeric_frame(path: Path, feature_names: List[str]) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [f for f in feature_names if f not in df.columns]
    if missing:
        raise ValueError(f"{path} missing features: {missing[:20]}")
    x = df.loc[:, feature_names].copy()
    for c in feature_names:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    if x.isna().any().any() or np.isinf(x.to_numpy(dtype=np.float64)).any():
        bad = [c for c in feature_names if x[c].isna().any() or np.isinf(x[c].to_numpy(dtype=np.float64)).any()]
        raise ValueError(f"NaN/Inf found after numeric conversion in {path}: {bad[:20]}")
    return x


def fractional_rank_values(values: np.ndarray, uniq: np.ndarray) -> np.ndarray:
    """Map values to fractional rank index in [0, n_unique-1] using train unique values."""
    n = int(uniq.size)
    if n <= 1:
        return np.zeros(values.shape, dtype=np.float64)
    v = values.astype(np.float64, copy=False)
    idx = np.searchsorted(uniq, v, side="left")
    idx = np.clip(idx, 0, n - 1)

    # Exact hits or outside bounds.
    exact = uniq[idx] == v
    out = idx.astype(np.float64)

    # Values below min -> 0, above max -> n-1.
    below = v <= uniq[0]
    above = v >= uniq[-1]
    out[below] = 0.0
    out[above] = float(n - 1)

    # Interior non-exact values: interpolate between neighbouring unique raw values.
    mask = ~(exact | below | above)
    if np.any(mask):
        right = idx[mask]
        left = right - 1
        lo = uniq[left]
        hi = uniq[right]
        denom = hi - lo
        frac = np.zeros_like(lo, dtype=np.float64)
        nz = denom != 0
        frac[nz] = (v[mask][nz] - lo[nz]) / denom[nz]
        frac = np.clip(frac, 0.0, 1.0)
        out[mask] = left.astype(np.float64) + frac
    return out


def pos_to_bin_offset(pos: np.ndarray, K: int) -> Tuple[np.ndarray, np.ndarray]:
    # D3 has Embedding(K+1); bin is 0..K-1 and offset is [0,1). bin+1 is safe.
    pos = np.asarray(pos, dtype=np.float64)
    pos = np.clip(pos, 0.0, float(K - 1))
    b = np.floor(pos).astype(np.int64)
    b = np.clip(b, 0, K - 1)
    off = (pos - b.astype(np.float64)).astype(np.float32)
    off = np.clip(off, 0.0, 1.0).astype(np.float32)
    return b, off


def encode_rank_safe(train_col: np.ndarray, val_col: np.ndarray, K: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    uniq = np.unique(train_col.astype(np.float64))
    n = int(uniq.size)
    if n <= 1:
        ztr = np.zeros(train_col.shape, dtype=np.float64)
        zva = np.zeros(val_col.shape, dtype=np.float64)
    else:
        tr_rank = fractional_rank_values(train_col, uniq)
        va_rank = fractional_rank_values(val_col, uniq)
        # Corrected: use K-1, not K. This avoids the old divisor aliasing trap.
        ztr = tr_rank / float(n - 1) * float(K - 1)
        zva = va_rank / float(n - 1) * float(K - 1)
    btr, otr = pos_to_bin_offset(ztr, K)
    bva, ova = pos_to_bin_offset(zva, K)
    info = {
        "rank_n_unique": n,
        "rank_old_alias_risk_K_mod_nminus1_eq0": bool(n > 1 and (K % (n - 1) == 0)),
        "rank_new_uses_K_minus_1": True,
    }
    return btr, otr, bva, ova, info


def encode_abs_uniform(train_col: np.ndarray, val_col: np.ndarray, K: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    tr = train_col.astype(np.float64)
    va = val_col.astype(np.float64)
    mn = float(np.min(tr))
    mx = float(np.max(tr))
    denom = mx - mn
    if not np.isfinite(denom) or abs(denom) < 1e-12:
        ztr = np.zeros(tr.shape, dtype=np.float64)
        zva = np.zeros(va.shape, dtype=np.float64)
        constant = True
    else:
        ztr01 = np.clip((tr - mn) / denom, 0.0, 1.0)
        zva01 = np.clip((va - mn) / denom, 0.0, 1.0)
        ztr = ztr01 * float(K - 1)
        zva = zva01 * float(K - 1)
        constant = False
    btr, otr = pos_to_bin_offset(ztr, K)
    bva, ova = pos_to_bin_offset(zva, K)
    info = {"abs_min": mn, "abs_max": mx, "abs_constant": constant, "abs_uses_K_minus_1": True}
    return btr, otr, bva, ova, info


def encode_compact(train_col: np.ndarray, val_col: np.ndarray, K: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    tr = train_col.astype(np.float64)
    va = val_col.astype(np.float64)
    uniq = np.unique(tr)
    n = int(uniq.size)
    if n <= K:
        tr_idx = np.searchsorted(uniq, tr, side="left")
        va_idx = np.searchsorted(uniq, va, side="left")
        exact = (va_idx < n) & (uniq[np.clip(va_idx, 0, n - 1)] == va)
        # For unseen val values, put them at insertion rank clipped to valid token id.
        va_idx = np.clip(va_idx, 0, max(0, n - 1))
        btr = tr_idx.astype(np.int64)
        bva = va_idx.astype(np.int64)
        unseen_val = int((~exact).sum())
    else:
        # Rare fallback: low-unique policy unexpectedly has >K unique; use rank-safe.
        btr, otr, bva, ova, info = encode_rank_safe(tr, va, K)
        info.update({"compact_fallback_to_rank_safe": True})
        return btr, otr, bva, ova, info
    otr = np.zeros(tr.shape, dtype=np.float32)
    ova = np.zeros(va.shape, dtype=np.float32)
    info = {"compact_n_unique": n, "compact_unseen_val_count": unseen_val, "compact_offset_zero": True}
    return btr, otr, bva, ova, info


def encode_constant(train_col: np.ndarray, val_col: np.ndarray, K: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    btr = np.zeros(train_col.shape, dtype=np.int64)
    bva = np.zeros(val_col.shape, dtype=np.int64)
    otr = np.zeros(train_col.shape, dtype=np.float32)
    ova = np.zeros(val_col.shape, dtype=np.float32)
    return btr, otr, bva, ova, {"constant": True}


def entropy_norm_from_counts(counts: np.ndarray) -> float:
    counts = counts[counts > 0]
    if counts.size <= 1:
        return 0.0
    p = counts.astype(np.float64) / float(counts.sum())
    h = -float(np.sum(p * np.log(p + 1e-12)))
    return float(h / math.log(float(counts.size))) if counts.size > 1 else 0.0


def token_diag(feature: str, strategy: str, raw_col: np.ndarray, b: np.ndarray, off: np.ndarray, K: int, split: str, extra: Dict[str, Any] | None = None) -> Dict[str, Any]:
    raw_unique = int(np.unique(raw_col.astype(np.float64)).size)
    b = np.asarray(b, dtype=np.int64)
    off = np.asarray(off, dtype=np.float32)
    counts = np.bincount(np.clip(b, 0, K - 1), minlength=K)
    used = counts > 0
    used_counts = counts[used]
    bins_used = int(used.sum())
    possible_unique = max(1, min(raw_unique, K))
    dominant_bin_ratio = float(used_counts.max() / b.size) if used_counts.size else 0.0
    rare_bins_le5 = int((used_counts <= 5).sum()) if used_counts.size else 0
    rare_used_bin_ratio_le5 = float(rare_bins_le5 / bins_used) if bins_used else 0.0
    rare_sample_ratio_le5 = float(used_counts[used_counts <= 5].sum() / b.size) if used_counts.size else 0.0
    occupied = np.flatnonzero(used)
    gaps = np.diff(occupied) if occupied.size >= 2 else np.array([], dtype=np.int64)
    d: Dict[str, Any] = {
        "feature": feature,
        "split": split,
        "strategy": strategy,
        "K": int(K),
        "raw_unique": raw_unique,
        "bins_used": bins_used,
        "dead_bins": int(K - bins_used),
        "dead_bins_ratio": float((K - bins_used) / K),
        "possible_unique": possible_unique,
        "preserve_ratio": float(bins_used / possible_unique) if possible_unique else 0.0,
        "compression_factor": float(raw_unique / max(1, bins_used)),
        "entropy_norm": entropy_norm_from_counts(counts),
        "dominant_bin_ratio": dominant_bin_ratio,
        "rare_bins_le5": rare_bins_le5,
        "rare_used_bin_ratio_le5": rare_used_bin_ratio_le5,
        "rare_sample_ratio_le5": rare_sample_ratio_le5,
        "offset_nonzero_ratio": float(np.mean(np.abs(off) > 1e-7)),
        "offset_zero_ratio": float(np.mean(np.abs(off) <= 1e-7)),
        "offset_unique_count_rounded_1e6": int(np.unique(np.round(off.astype(np.float64), 6)).size),
        "offset_mean": float(np.mean(off)),
        "offset_std": float(np.std(off)),
        "integer_position_ratio_inferred": float(np.mean(np.abs(off) <= 1e-7)),
        "used_even_bins": int(((occupied % 2) == 0).sum()) if occupied.size else 0,
        "used_odd_bins": int(((occupied % 2) == 1).sum()) if occupied.size else 0,
        "used_odd_bin_ratio": float((((occupied % 2) == 1).sum()) / occupied.size) if occupied.size else 0.0,
        "occupied_gap_mean": float(np.mean(gaps)) if gaps.size else 0.0,
        "occupied_gap_max": int(np.max(gaps)) if gaps.size else 0,
        "occupied_gap_min": int(np.min(gaps)) if gaps.size else 0,
    }
    if extra:
        d.update(extra)
    return d


def c2_diag_for_compare(feature_names: List[str], c2_data: Dict[str, np.ndarray], train_raw: pd.DataFrame, K: int = 512) -> pd.DataFrame | None:
    if "X_train_bin" not in c2_data or "X_train_offset" not in c2_data:
        return None
    Xb = c2_data["X_train_bin"].astype(np.int64)
    Of = c2_data["X_train_offset"].astype(np.float32)
    rows = []
    for j, f in enumerate(feature_names):
        rows.append(token_diag(f, "C2_existing", train_raw[f].to_numpy(dtype=np.float64), Xb[:, j], Of[:, j], K, "train"))
    return pd.DataFrame(rows)


def build_variant(
    *,
    variant: str,
    K: int,
    out_dir: Path,
    feature_names: List[str],
    strategy_map: Dict[str, str],
    train_raw: pd.DataFrame,
    val_raw: pd.DataFrame,
    c2_data: Dict[str, np.ndarray],
    c2_meta: Dict[str, Any],
    c2_ds_path: Path,
    c2_meta_path: Path,
) -> None:
    Ntr = int(train_raw.shape[0])
    Nva = int(val_raw.shape[0])
    F = len(feature_names)
    Xtr_b = np.zeros((Ntr, F), dtype=np.int64)
    Xva_b = np.zeros((Nva, F), dtype=np.int64)
    Xtr_o = np.zeros((Ntr, F), dtype=np.float32)
    Xva_o = np.zeros((Nva, F), dtype=np.float32)

    train_rows: List[Dict[str, Any]] = []
    val_rows: List[Dict[str, Any]] = []
    rank_rows: List[Dict[str, Any]] = []

    for j, f in enumerate(feature_names):
        strat0 = normalize_strategy(strategy_map[f])
        tr = train_raw[f].to_numpy(dtype=np.float64)
        va = val_raw[f].to_numpy(dtype=np.float64)
        raw_unique = int(np.unique(tr).size)
        if raw_unique <= 1:
            strat = STRATEGY_CONST
        else:
            strat = strat0

        encode_strategy = strat
        extra: Dict[str, Any]
        if strat == STRATEGY_CONST:
            btr, otr, bva, ova, extra = encode_constant(tr, va, K)
        elif strat == STRATEGY_COMPACT:
            btr, otr, bva, ova, extra = encode_compact(tr, va, K)
        elif strat == STRATEGY_RANK:
            if variant == "abs_for_rank_control":
                btr, otr, bva, ova, extra = encode_abs_uniform(tr, va, K)
                encode_strategy = "rank_replaced_by_abs_uniform_control"
            else:
                btr, otr, bva, ova, extra = encode_rank_safe(tr, va, K)
                encode_strategy = STRATEGY_RANK
        else:
            # Native K1024 keep_current: absolute train-minmax uniform. No 0..511 leftover.
            btr, otr, bva, ova, extra = encode_abs_uniform(tr, va, K)
            encode_strategy = STRATEGY_KEEP

        Xtr_b[:, j] = btr
        Xva_b[:, j] = bva
        Xtr_o[:, j] = otr
        Xva_o[:, j] = ova

        base_extra = dict(extra)
        base_extra.update({"original_c2_strategy": strat0, "effective_strategy": encode_strategy, "feature_index": j})
        train_rows.append(token_diag(f, encode_strategy, tr, btr, otr, K, "train", base_extra))
        val_rows.append(token_diag(f, encode_strategy, va, bva, ova, K, "val", base_extra))
        if strat0 == STRATEGY_RANK:
            rr = {"feature": f, "variant": variant, "K": K, **base_extra}
            rr.update({
                "train_bins_used": train_rows[-1]["bins_used"],
                "train_offset_nonzero_ratio": train_rows[-1]["offset_nonzero_ratio"],
                "train_dead_bins_ratio": train_rows[-1]["dead_bins_ratio"],
                "train_used_odd_bin_ratio": train_rows[-1]["used_odd_bin_ratio"],
                "train_integer_position_ratio_inferred": train_rows[-1]["integer_position_ratio_inferred"],
            })
            rank_rows.append(rr)

    out_dir.mkdir(parents=True, exist_ok=True)
    dataset_path = out_dir / "mixed_quantile_offset_dataset.npz"
    np.savez_compressed(
        dataset_path,
        X_train_bin=Xtr_b.astype(np.int64),
        X_train_offset=Xtr_o.astype(np.float32),
        y_train=c2_data["y_train"].astype(np.int64),
        X_val_bin=Xva_b.astype(np.int64),
        X_val_offset=Xva_o.astype(np.float32),
        y_val=c2_data["y_val"].astype(np.int64),
    )

    train_diag = pd.DataFrame(train_rows)
    val_diag = pd.DataFrame(val_rows)
    train_diag.to_csv(out_dir / "tokenization_diagnostics_train.csv", index=False)
    val_diag.to_csv(out_dir / "tokenization_diagnostics_val.csv", index=False)
    pd.DataFrame(rank_rows).to_csv(out_dir / "rank_mapping_diagnostics.csv", index=False)

    c2_compare = c2_diag_for_compare(feature_names, c2_data, train_raw, K=512)
    if c2_compare is not None:
        k1024_small = train_diag[[
            "feature", "effective_strategy", "raw_unique", "bins_used", "dead_bins_ratio", "preserve_ratio",
            "compression_factor", "entropy_norm", "dominant_bin_ratio", "rare_used_bin_ratio_le5",
            "offset_nonzero_ratio", "offset_unique_count_rounded_1e6", "used_odd_bin_ratio",
        ]].rename(columns={
            "effective_strategy": "k1024_strategy",
            "bins_used": "k1024_bins_used",
            "dead_bins_ratio": "k1024_dead_bins_ratio",
            "preserve_ratio": "k1024_preserve_ratio",
            "compression_factor": "k1024_compression_factor",
            "entropy_norm": "k1024_entropy_norm",
            "dominant_bin_ratio": "k1024_dominant_bin_ratio",
            "rare_used_bin_ratio_le5": "k1024_rare_used_bin_ratio_le5",
            "offset_nonzero_ratio": "k1024_offset_nonzero_ratio",
            "offset_unique_count_rounded_1e6": "k1024_offset_unique_count",
            "used_odd_bin_ratio": "k1024_used_odd_bin_ratio",
        })
        c2_small = c2_compare[[
            "feature", "bins_used", "dead_bins_ratio", "preserve_ratio", "compression_factor", "entropy_norm",
            "dominant_bin_ratio", "rare_used_bin_ratio_le5", "offset_nonzero_ratio", "offset_unique_count_rounded_1e6",
            "used_odd_bin_ratio",
        ]].rename(columns={
            "bins_used": "c2_bins_used",
            "dead_bins_ratio": "c2_dead_bins_ratio",
            "preserve_ratio": "c2_preserve_ratio",
            "compression_factor": "c2_compression_factor",
            "entropy_norm": "c2_entropy_norm",
            "dominant_bin_ratio": "c2_dominant_bin_ratio",
            "rare_used_bin_ratio_le5": "c2_rare_used_bin_ratio_le5",
            "offset_nonzero_ratio": "c2_offset_nonzero_ratio",
            "offset_unique_count_rounded_1e6": "c2_offset_unique_count",
            "used_odd_bin_ratio": "c2_used_odd_bin_ratio",
        })
        cmp = c2_small.merge(k1024_small, on="feature", how="inner")
        cmp["delta_bins_used"] = cmp["k1024_bins_used"] - cmp["c2_bins_used"]
        cmp["delta_entropy_norm"] = cmp["k1024_entropy_norm"] - cmp["c2_entropy_norm"]
        cmp["delta_rare_used_bin_ratio_le5"] = cmp["k1024_rare_used_bin_ratio_le5"] - cmp["c2_rare_used_bin_ratio_le5"]
        cmp.to_csv(out_dir / "c2_vs_k1024_tokenization_train.csv", index=False)

    strategy_counts = train_diag["effective_strategy"].value_counts().to_dict()
    original_strategy_counts = train_diag["original_c2_strategy"].value_counts().to_dict()
    group_summary = (
        train_diag.groupby("effective_strategy")[[
            "bins_used", "dead_bins_ratio", "preserve_ratio", "compression_factor", "entropy_norm",
            "dominant_bin_ratio", "rare_used_bin_ratio_le5", "offset_nonzero_ratio", "used_odd_bin_ratio",
        ]]
        .mean(numeric_only=True)
        .reset_index()
        .to_dict(orient="records")
    )
    global_summary = {
        "variant": variant,
        "K": K,
        "dataset_path": str(dataset_path),
        "metadata_path": str(out_dir / "mixed_quantile_offset_metadata.json"),
        "source_c2_dataset": str(c2_ds_path),
        "source_c2_metadata": str(c2_meta_path),
        "n_train": Ntr,
        "n_val": Nva,
        "n_features": F,
        "strategy_counts": strategy_counts,
        "original_c2_strategy_counts": original_strategy_counts,
        "group_summary_train": group_summary,
        "global_mean_bins_used": float(train_diag["bins_used"].mean()),
        "global_mean_entropy_norm": float(train_diag["entropy_norm"].mean()),
        "global_mean_rare_used_bin_ratio_le5": float(train_diag["rare_used_bin_ratio_le5"].mean()),
        "global_mean_offset_nonzero_ratio": float(train_diag["offset_nonzero_ratio"].mean()),
        "rank_alias_risk_features_old_formula": int(train_diag.get("rank_old_alias_risk_K_mod_nminus1_eq0", pd.Series(dtype=bool)).fillna(False).sum()) if "rank_old_alias_risk_K_mod_nminus1_eq0" in train_diag.columns else 0,
        "notes": [
            "All features regenerated natively at K=1024; no K512 keep_current leftovers.",
            "rank_safe uses rank/(n_unique-1)*(K-1), not rank/(n_unique-1)*K.",
            "dead_bins_ratio can remain high when raw_unique < K; that is intrinsic, not necessarily an alias bug.",
        ],
    }
    (out_dir / "global_tokenization_summary.json").write_text(json.dumps(global_summary, indent=2, ensure_ascii=False), encoding="utf-8")

    # Metadata used by existing D3 training script.
    meta_out = {
        "stage": "build_k1024_fixed_c2_policy",
        "variant": variant,
        "K": K,
        "num_bins": K,
        "n_features": F,
        "feature_names": feature_names,
        "label_mapping": c2_meta.get("label_mapping", {}),
        "strategy_counts": strategy_counts,
        "original_c2_strategy_counts": original_strategy_counts,
        "feature_policy": {
            row["feature"]: {
                "original_c2_strategy": row["original_c2_strategy"],
                "effective_strategy": row["effective_strategy"],
                "strategy": row["effective_strategy"],
            }
            for row in train_rows
        },
        "input": {
            "source_c2_dataset": str(c2_ds_path),
            "source_c2_metadata": str(c2_meta_path),
            "train_raw": str(resolve_path("01_split/train_raw.csv")) if Path("01_split/train_raw.csv").exists() else "01_split/train_raw.csv",
            "val_raw": str(resolve_path("01_split/val_raw.csv")) if Path("01_split/val_raw.csv").exists() else "01_split/val_raw.csv",
            "train_preprocessed": c2_meta.get("input", {}).get("train_preprocessed", "03_outputs/preprocessing/train_preprocessed_K1000.csv"),
            "val_preprocessed": c2_meta.get("input", {}).get("val_preprocessed", "03_outputs/preprocessing/val_preprocessed_K1000.csv"),
        },
        "diagnostics": global_summary,
    }
    (out_dir / "mixed_quantile_offset_metadata.json").write_text(json.dumps(meta_out, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"[OK] Built {variant}: {out_dir}")
    print(json.dumps({"variant": variant, "strategy_counts": strategy_counts, "global_mean_bins_used": global_summary["global_mean_bins_used"], "global_mean_entropy_norm": global_summary["global_mean_entropy_norm"]}, indent=2))


def main() -> None:
    args = parse_args()
    K = int(args.K)
    c2_dir = resolve_path(args.c2_dir)
    train_path = resolve_path(args.train_raw)
    val_path = resolve_path(args.val_raw)
    out_root = resolve_path(args.out_root) if Path(args.out_root).exists() else repo_root() / args.out_root

    c2_data, c2_meta, c2_ds_path, c2_meta_path = load_c2(c2_dir)
    feature_names = [str(x) for x in c2_meta["feature_names"]]
    strategy_map = get_strategy_map(c2_dir, c2_meta, feature_names)

    train_raw = safe_numeric_frame(train_path, feature_names)
    val_raw = safe_numeric_frame(val_path, feature_names)

    print("[input] C2 dir:", c2_dir)
    print("[input] train raw:", train_path, train_raw.shape)
    print("[input] val raw:", val_path, val_raw.shape)
    print("[input] features:", len(feature_names))
    print("[input] C2 strategies:", pd.Series(strategy_map).value_counts().to_dict())

    for variant in args.variants:
        if variant == "rank_safe":
            out_dir = out_root / "K1024_B1024_C2policy_rank_safe_native"
        elif variant == "abs_for_rank_control":
            out_dir = out_root / "K1024_B1024_C2policy_abs_for_rank_control_native"
        else:
            raise ValueError(variant)
        build_variant(
            variant=variant,
            K=K,
            out_dir=out_dir,
            feature_names=feature_names,
            strategy_map=strategy_map,
            train_raw=train_raw,
            val_raw=val_raw,
            c2_data=c2_data,
            c2_meta=c2_meta,
            c2_ds_path=c2_ds_path,
            c2_meta_path=c2_meta_path,
        )


if __name__ == "__main__":
    main()
