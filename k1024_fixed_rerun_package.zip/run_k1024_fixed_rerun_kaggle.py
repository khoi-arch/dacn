#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kaggle runner for corrected K1024 C2-policy D3 rerun."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


def run(cmd: list[str], cwd: Path) -> None:
    print("\n$", " ".join(cmd), flush=True)
    p = subprocess.Popen(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    assert p.stdout is not None
    for line in p.stdout:
        print(line, end="", flush=True)
    code = p.wait()
    if code != 0:
        raise subprocess.CalledProcessError(code, cmd)


def zip_dir(zip_path: Path, items: list[Path], root: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in items:
            if not item.exists():
                continue
            if item.is_file():
                z.write(item, item.relative_to(root).as_posix())
            else:
                for p in item.rglob("*"):
                    if p.is_file():
                        z.write(p, p.relative_to(root).as_posix())
    print(f"[ZIP] {zip_path}", flush=True)


def find_train_script(repo: Path) -> Path:
    candidates = [
        repo / "02_src" / "10_train_fusion_ablation_D0_D7.py",
        repo / "02_src" / "26_train_d3_lstm_mha.py",  # fallback only if baseline train script absent
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Cannot find D3 training script. Expected 02_src/10_train_fusion_ablation_D0_D7.py")


def main() -> None:
    repo = Path.cwd()
    print("[repo]", repo, flush=True)

    build_script = repo / "02_src" / "27_build_k1024_fixed_artifacts.py"
    if not build_script.exists():
        raise FileNotFoundError(str(build_script))

    c2_dir = repo / "03_outputs" / "build_mixed_quantile_offset" / "K512_B512_C2_selective_rank_discrete_compact"
    if not c2_dir.exists():
        raise FileNotFoundError(f"Missing C2 artifact dir: {c2_dir}")

    # 1) Build corrected K1024 artifacts and full token diagnostics.
    run([
        sys.executable, "-u", str(build_script.relative_to(repo)),
        "--K", "1024",
        "--c2-dir", str(c2_dir.relative_to(repo)),
        "--train-raw", "01_split/train_raw.csv",
        "--val-raw", "01_split/val_raw.csv",
        "--out-root", "03_outputs/build_mixed_quantile_offset",
        "--variants", "rank_safe", "abs_for_rank_control",
    ], cwd=repo)

    # 2) Train D3 Transformer baseline on both corrected K1024 artifacts.
    train_script = find_train_script(repo)
    train_rel = str(train_script.relative_to(repo))
    out_root = repo / "03_outputs" / "train_runs_k1024_fixed_c2policy"
    out_root.mkdir(parents=True, exist_ok=True)

    variants = [
        (
            "T1_K1024_C2POLICY_RANK_SAFE_NATIVE_D3",
            repo / "03_outputs" / "build_mixed_quantile_offset" / "K1024_B1024_C2policy_rank_safe_native",
        ),
        (
            "T2_K1024_C2POLICY_ABS_FOR_RANK_CONTROL_NATIVE_D3",
            repo / "03_outputs" / "build_mixed_quantile_offset" / "K1024_B1024_C2policy_abs_for_rank_control_native",
        ),
    ]

    for run_name, art_dir in variants:
        ds = art_dir / "mixed_quantile_offset_dataset.npz"
        meta = art_dir / "mixed_quantile_offset_metadata.json"
        if not ds.exists() or not meta.exists():
            raise FileNotFoundError(f"Missing built artifact for {run_name}: {art_dir}")
        run([
            sys.executable, "-u", train_rel,
            "--run-id", "D3",
            "--K", "1024",
            "--num-bins", "1024",
            "--dataset-npz", str(ds),
            "--metadata-json", str(meta),
            "--out-root", str(out_root),
            "--run-name", run_name,
            "--epochs", "80",
            "--patience", "12",
            "--batch-size", "256",
            "--seed", "42",
        ], cwd=repo)

    # 3) Make a small index summary if diagnosis_summary exists.
    summaries = []
    for run_dir in sorted(out_root.rglob("diagnosis_summary.json")):
        try:
            d = json.loads(run_dir.read_text(encoding="utf-8"))
            summaries.append({
                "run": run_dir.parent.name,
                "path": str(run_dir.parent.relative_to(repo)),
                "best_epoch": d.get("best_epoch"),
                "train_macro_f1": d.get("train", {}).get("macro_f1"),
                "val_macro_f1": d.get("val", {}).get("macro_f1"),
                "gap": d.get("generalization_gap_macro_f1"),
                "malware_only_f1": d.get("val", {}).get("malware_only_avg_f1"),
            })
        except Exception as e:
            summaries.append({"path": str(run_dir), "error": str(e)})
    summary_path = repo / "03_outputs" / "k1024_fixed_rerun_index.json"
    summary_path.write_text(json.dumps(summaries, indent=2, ensure_ascii=False), encoding="utf-8")
    print("[SUMMARY]", json.dumps(summaries, indent=2), flush=True)

    zip_path = Path("/kaggle/working/k1024_fixed_rerun_outputs.zip")
    items = [
        repo / "03_outputs" / "build_mixed_quantile_offset" / "K1024_B1024_C2policy_rank_safe_native",
        repo / "03_outputs" / "build_mixed_quantile_offset" / "K1024_B1024_C2policy_abs_for_rank_control_native",
        out_root,
        summary_path,
    ]
    zip_dir(zip_path, items, repo)
    print("\nDONE:", zip_path, flush=True)


if __name__ == "__main__":
    main()
