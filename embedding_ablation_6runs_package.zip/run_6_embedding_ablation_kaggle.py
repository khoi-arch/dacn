from pathlib import Path
import subprocess, time, os, zipfile, json

ROOT = Path('/kaggle/working/dacn')
LOG_DIR = ROOT / '03_outputs/parallel_logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)

ARTIFACTS = {
    'C2_K512': ROOT / '03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact',
    'B_K512': ROOT / '03_outputs/build_mixed_quantile_offset/K512_B512_rank_uniform_only',
    'C4a_K1024': ROOT / '03_outputs/build_mixed_quantile_offset/K1024_B1024_C4a_rank1024_rest_C2',
}

for name, d in ARTIFACTS.items():
    npz = d / 'mixed_quantile_offset_dataset.npz'
    meta = d / 'mixed_quantile_offset_metadata.json'
    print(name, 'npz', npz.exists(), npz)
    print(name, 'meta', meta.exists(), meta)
    if not npz.exists() or not meta.exists():
        raise FileNotFoundError(f'Missing artifact {name}: {d}')

COMMON = [
    'python', '-u', '02_src/20_train_embedding_batch_ablation.py',
    '--epochs', '80',
    '--batch-size', '256',
    '--scheduler', 'warmup_cosine',
    '--warmup-epochs', '8',
    '--patience', '12',
    '--min-delta', '1e-4',
    '--value-dim', '32',
    '--feature-dim', '32',
    '--hidden-dim', '128',
    '--num-layers', '3',
    '--num-heads', '4',
    '--dropout', '0.1',
    '--classifier-dropout', '0.1',
    '--d3s2r-width-space', 'signed_log1p',
    '--d3s2r-width-tau', '1.0',
    '--d3s2r-min-bin-count', '2',
]

def art_args(name):
    d = ARTIFACTS[name]
    return ['--dataset-npz', str(d / 'mixed_quantile_offset_dataset.npz'), '--metadata-json', str(d / 'mixed_quantile_offset_metadata.json')]

RUNS = [
    {
        'wave': 1,
        'gpu': 0,
        'tag': 'T1_C2_K512_D3PF_only',
        'cmd': COMMON + art_args('C2_K512') + [
            '--run-id', 'D3PF', '--K', '512', '--num-bins', '512',
            '--run-name', 'T1_C2_K512_D3PF_only',
            '--device', 'cuda:0',
            '--per-feature-init', 'shared_clone',
            '--value-embedding-dropout', '0',
            '--d3s2r-lambda-rank', '0', '--d3s2r-lambda-current', '0', '--d3s2r-lambda-compact', '0',
            '--weight-decay', '1e-4',
        ],
    },
    {
        'wave': 1,
        'gpu': 1,
        'tag': 'T2_B_K512_D3PF_only',
        'cmd': COMMON + art_args('B_K512') + [
            '--run-id', 'D3PF', '--K', '512', '--num-bins', '512',
            '--run-name', 'T2_B_K512_D3PF_only',
            '--device', 'cuda:1',
            '--per-feature-init', 'shared_clone',
            '--value-embedding-dropout', '0',
            '--d3s2r-lambda-rank', '0', '--d3s2r-lambda-current', '0', '--d3s2r-lambda-compact', '0',
            '--weight-decay', '1e-4',
        ],
    },
    {
        'wave': 2,
        'gpu': 0,
        'tag': 'T3_C4a_K1024_D3REG_shared_smooth_dropout',
        'cmd': COMMON + art_args('C4a_K1024') + [
            '--run-id', 'D3REG', '--K', '1024', '--num-bins', '1024',
            '--run-name', 'T3_C4a_K1024_D3REG_shared_smooth_dropout',
            '--device', 'cuda:0',
            '--value-embedding-dropout', '0.05',
            '--d3s2r-lambda-rank', '1e-3', '--d3s2r-lambda-current', '0', '--d3s2r-lambda-compact', '0',
            '--weight-decay', '3e-4',
        ],
    },
    {
        'wave': 2,
        'gpu': 1,
        'tag': 'T4_C4a_K1024_D3PF_only',
        'cmd': COMMON + art_args('C4a_K1024') + [
            '--run-id', 'D3PF', '--K', '1024', '--num-bins', '1024',
            '--run-name', 'T4_C4a_K1024_D3PF_only',
            '--device', 'cuda:1',
            '--per-feature-init', 'shared_clone',
            '--value-embedding-dropout', '0',
            '--d3s2r-lambda-rank', '0', '--d3s2r-lambda-current', '0', '--d3s2r-lambda-compact', '0',
            '--weight-decay', '1e-4',
        ],
    },
    {
        'wave': 3,
        'gpu': 0,
        'tag': 'T5_C4a_K1024_D3PFREG_smooth',
        'cmd': COMMON + art_args('C4a_K1024') + [
            '--run-id', 'D3PFREG', '--K', '1024', '--num-bins', '1024',
            '--run-name', 'T5_C4a_K1024_D3PFREG_smooth',
            '--device', 'cuda:0',
            '--per-feature-init', 'shared_clone',
            '--value-embedding-dropout', '0',
            '--d3s2r-lambda-rank', '1e-3', '--d3s2r-lambda-current', '0', '--d3s2r-lambda-compact', '0',
            '--weight-decay', '1e-4',
        ],
    },
    {
        'wave': 3,
        'gpu': 1,
        'tag': 'T6_C4a_K1024_D3PFREG_smooth_dropout_wd',
        'cmd': COMMON + art_args('C4a_K1024') + [
            '--run-id', 'D3PFREG', '--K', '1024', '--num-bins', '1024',
            '--run-name', 'T6_C4a_K1024_D3PFREG_smooth_dropout_wd',
            '--device', 'cuda:1',
            '--per-feature-init', 'shared_clone',
            '--value-embedding-dropout', '0.05',
            '--d3s2r-lambda-rank', '3e-3', '--d3s2r-lambda-current', '0', '--d3s2r-lambda-compact', '0',
            '--weight-decay', '3e-4',
        ],
    },
]

def run_wave(wave):
    wave_runs = [r for r in RUNS if r['wave'] == wave]
    procs = []
    for r in wave_runs:
        log = LOG_DIR / f"{r['tag']}.log"
        print('Starting', r['tag'], 'gpu', r['gpu'])
        print(' '.join(r['cmd']))
        f = open(log, 'w')
        p = subprocess.Popen(r['cmd'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
        procs.append((r, p, f, log))

    while True:
        all_done = True
        print(f"\n========== WAVE {wave} STATUS ==========")
        for r, p, f, log in procs:
            rc = p.poll()
            print(r['tag'], 'running' if rc is None else f'done rc={rc}')
            all_done = all_done and (rc is not None)
        print('\n========== GPU ==========' )
        os.system('nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader')
        for r, p, f, log in procs:
            print(f"\n========== {r['tag']} last 20 lines ==========")
            os.system(f'tail -20 {log}')
        if all_done:
            break
        time.sleep(30)

    failed = []
    for r, p, f, log in procs:
        f.close()
        if p.returncode != 0:
            failed.append((r['tag'], p.returncode, str(log)))
    if failed:
        print('FAILED RUNS:', failed)
        raise SystemExit(1)

for wave in [1, 2, 3]:
    run_wave(wave)

# Zip outputs
out_zip = Path('/kaggle/working/embedding_ablation_6runs_outputs.zip')
items = []
for r in RUNS:
    K = 'Keff1024' if 'K1024' in r['tag'] else 'Keff512'
    run_dir = ROOT / '03_outputs/train_runs_fusion_ablation_D0_D7' / K / r['tag']
    for fname in [
        'diagnosis_summary.json',
        'val_classification_report_best.json',
        'val_confusion_matrix_best.csv',
        'history.csv',
        'config.json',
        'd3s2r_width_weight_summary.csv',
        'd3s2r_smooth_coeff.npy',
    ]:
        items.append(run_dir / fname)
    items.append(LOG_DIR / f"{r['tag']}.log")

missing = []
with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in items:
        if p.exists():
            z.write(p, str(p).replace('/kaggle/working/', ''))
        else:
            missing.append(str(p))

print('Wrote:', out_zip)
print('Size:', out_zip.stat().st_size if out_zip.exists() else None)
print('Missing optional files:')
for m in missing:
    print(m)
