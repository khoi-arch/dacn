#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Faithful Piecewise Feature Embedding + BiLSTM + MHA baseline adapted to current DACN splits.

Pipeline reproduced from the uploaded report:
  - X shape: (B, F, 2) with channels (bin_id, offset)
  - gaussian-like: bin_id=0, offset=z-score
  - binary/one-hot: bin_id=0, offset=0/1
  - highly skewed: quantile bins + offset within quantile interval
  - OOD-low / OOD-high bins for values outside train-fit range
  - embedding: bin Emb + offset Linear -> concat Linear -> v(value)
  - token: LayerNorm(v(value) + v(feature))
  - backbone: BiLSTM -> MultiHeadAttention -> attention pooling -> classifier
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)

TARGET_COLS = {"label_L1", "label_L2", "label_L3", "Class", "Category"}


# -----------------------------
# Utils
# -----------------------------

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = False


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def save_json(obj: Any, path: Path) -> None:
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def as_str_list(arr: np.ndarray) -> List[str]:
    out: List[str] = []
    for x in arr:
        if isinstance(x, bytes):
            out.append(x.decode("utf-8"))
        else:
            out.append(str(x))
    return out


def load_feature_names_and_labels(dataset_npz: Path) -> Tuple[List[str], np.ndarray, np.ndarray, Optional[List[str]]]:
    with np.load(dataset_npz, allow_pickle=True) as data:
        if "feature_names" not in data.files:
            raise KeyError(f"{dataset_npz} missing feature_names")
        feature_names = as_str_list(data["feature_names"])
        y_train = data["y_train"].astype(np.int64)
        y_val = data["y_val"].astype(np.int64)
        label_names = as_str_list(data["label_names"]) if "label_names" in data.files else None
    return feature_names, y_train, y_val, label_names


def clean_numeric_frame(df: pd.DataFrame, feature_names: List[str], medians: Optional[pd.Series] = None, clip_negative: bool = True) -> Tuple[pd.DataFrame, pd.Series]:
    out = df.copy()
    for col in feature_names:
        if col not in out.columns:
            raise KeyError(f"Missing feature column: {col}")
    out = out[feature_names].replace([np.inf, -np.inf], np.nan)
    if medians is None:
        medians = out.median(axis=0, numeric_only=True)
    out = out.fillna(medians).fillna(0.0)
    out = out.astype(np.float32)
    if clip_negative:
        # Faithful to the uploaded report's clean() for non-label numeric columns.
        out = out.clip(lower=0.0)
    return out, medians


def is_binary_01(x: np.ndarray) -> bool:
    vals = np.unique(x[np.isfinite(x)])
    if vals.size == 0:
        return True
    if vals.size > 2:
        return False
    return bool(np.all(np.isin(vals, [0.0, 1.0])))


def safe_skew(x: np.ndarray) -> float:
    s = pd.Series(x.astype(np.float64)).skew()
    if pd.isna(s):
        return 0.0
    return float(s)


@dataclass
class FeatureFit:
    name: str
    kind: str  # constant, binary, gaussian_like, highly_skewed
    skew: float
    raw_unique: int
    median: float
    mean: Optional[float] = None
    std: Optional[float] = None
    quantile_edges: Optional[List[float]] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None


@dataclass
class PreprocessConfig:
    num_quantiles: int
    num_bins: int
    bin_continuous: int
    bin_ood_low: int
    bin_ood_high: int
    skew_threshold: float
    z_clip: Optional[float]
    clip_negative: bool


def fit_piecewise_preprocessor(
    train_df: pd.DataFrame,
    feature_names: List[str],
    num_quantiles: int,
    skew_threshold: float = 1.0,
    z_clip: Optional[float] = 10.0,
    clip_negative: bool = True,
) -> Tuple[List[FeatureFit], PreprocessConfig, pd.DataFrame, pd.Series]:
    clean_df, medians = clean_numeric_frame(train_df, feature_names, medians=None, clip_negative=clip_negative)

    fits: List[FeatureFit] = []
    qs = np.linspace(0.0, 1.0, num_quantiles + 1)

    for col in feature_names:
        x = clean_df[col].to_numpy(dtype=np.float64)
        finite = x[np.isfinite(x)]
        if finite.size == 0:
            finite = np.array([0.0], dtype=np.float64)
        raw_unique = int(np.unique(finite).size)
        med = float(np.median(finite))
        skew = safe_skew(finite)

        if raw_unique <= 1:
            fits.append(FeatureFit(name=col, kind="constant", skew=skew, raw_unique=raw_unique, median=med))
            continue

        if is_binary_01(finite):
            fits.append(FeatureFit(name=col, kind="binary", skew=skew, raw_unique=raw_unique, median=med))
            continue

        if abs(skew) < skew_threshold:
            mean = float(np.mean(finite))
            std = float(np.std(finite))
            if std <= 1e-12:
                std = 1.0
            fits.append(
                FeatureFit(
                    name=col,
                    kind="gaussian_like",
                    skew=skew,
                    raw_unique=raw_unique,
                    median=med,
                    mean=mean,
                    std=std,
                )
            )
            continue

        edges = np.quantile(finite, qs).astype(np.float64)
        # Keep duplicate edges: offset handles zero-width by setting 0.
        fits.append(
            FeatureFit(
                name=col,
                kind="highly_skewed",
                skew=skew,
                raw_unique=raw_unique,
                median=med,
                quantile_edges=[float(v) for v in edges],
                min_value=float(edges[0]),
                max_value=float(edges[-1]),
            )
        )

    cfg = PreprocessConfig(
        num_quantiles=num_quantiles,
        num_bins=num_quantiles + 3,
        bin_continuous=0,
        bin_ood_low=1,
        bin_ood_high=num_quantiles + 2,
        skew_threshold=skew_threshold,
        z_clip=z_clip,
        clip_negative=clip_negative,
    )
    return fits, cfg, clean_df, medians


def transform_piecewise(
    df: pd.DataFrame,
    feature_names: List[str],
    fits: List[FeatureFit],
    cfg: PreprocessConfig,
    medians: pd.Series,
) -> np.ndarray:
    clean_df, _ = clean_numeric_frame(df, feature_names, medians=medians, clip_negative=cfg.clip_negative)
    n = len(clean_df)
    Fnum = len(feature_names)
    X = np.zeros((n, Fnum, 2), dtype=np.float32)

    for j, fit in enumerate(fits):
        x = clean_df[fit.name].to_numpy(dtype=np.float64)
        bin_ids = np.zeros(n, dtype=np.int64)
        offsets = np.zeros(n, dtype=np.float64)

        if fit.kind == "constant":
            bin_ids[:] = cfg.bin_continuous
            offsets[:] = 0.0

        elif fit.kind == "binary":
            bin_ids[:] = cfg.bin_continuous
            offsets[:] = np.clip(x, 0.0, 1.0)

        elif fit.kind == "gaussian_like":
            mean = float(fit.mean if fit.mean is not None else 0.0)
            std = float(fit.std if fit.std is not None else 1.0)
            z = (x - mean) / std
            if cfg.z_clip is not None and cfg.z_clip > 0:
                z = np.clip(z, -cfg.z_clip, cfg.z_clip)
            bin_ids[:] = cfg.bin_continuous
            offsets[:] = z

        elif fit.kind == "highly_skewed":
            edges = np.asarray(fit.quantile_edges, dtype=np.float64)
            q = cfg.num_quantiles
            # OOD sentinels based on train-fit range. Matches report: < min = OOD-low, >= max = OOD-high.
            low_mask = x < edges[0]
            high_mask = x >= edges[-1]
            mid_mask = ~(low_mask | high_mask)

            bin_ids[low_mask] = cfg.bin_ood_low
            offsets[low_mask] = 0.0
            bin_ids[high_mask] = cfg.bin_ood_high
            offsets[high_mask] = 1.0

            if np.any(mid_mask):
                xm = x[mid_mask]
                idx = np.searchsorted(edges, xm, side="right") - 1
                idx = np.clip(idx, 0, q - 1)
                lo = edges[idx]
                hi = edges[idx + 1]
                denom = hi - lo
                off = np.zeros_like(xm, dtype=np.float64)
                ok = denom > 1e-12
                off[ok] = (xm[ok] - lo[ok]) / denom[ok]
                off = np.clip(off, 0.0, 1.0)
                bin_ids[mid_mask] = 2 + idx
                offsets[mid_mask] = off
        else:
            raise ValueError(f"Unknown feature kind {fit.kind}")

        X[:, j, 0] = bin_ids.astype(np.float32)
        X[:, j, 1] = offsets.astype(np.float32)

    return X


def summarize_preprocessing(X_train: np.ndarray, X_val: np.ndarray, fits: List[FeatureFit], cfg: PreprocessConfig) -> Dict[str, Any]:
    rows = []
    kind_counts: Dict[str, int] = {}
    for j, fit in enumerate(fits):
        kind_counts[fit.kind] = kind_counts.get(fit.kind, 0) + 1
        tr_bins = X_train[:, j, 0].astype(np.int64)
        va_bins = X_val[:, j, 0].astype(np.int64)
        tr_off = X_train[:, j, 1]
        va_off = X_val[:, j, 1]
        rows.append(
            {
                "feature": fit.name,
                "kind": fit.kind,
                "skew": fit.skew,
                "raw_unique": fit.raw_unique,
                "train_bins_used": int(np.unique(tr_bins).size),
                "val_bins_used": int(np.unique(va_bins).size),
                "train_ood_low_ratio": float(np.mean(tr_bins == cfg.bin_ood_low)),
                "train_ood_high_ratio": float(np.mean(tr_bins == cfg.bin_ood_high)),
                "val_ood_low_ratio": float(np.mean(va_bins == cfg.bin_ood_low)),
                "val_ood_high_ratio": float(np.mean(va_bins == cfg.bin_ood_high)),
                "train_offset_mean": float(np.mean(tr_off)),
                "train_offset_std": float(np.std(tr_off)),
                "val_offset_mean": float(np.mean(va_off)),
                "val_offset_std": float(np.std(va_off)),
            }
        )
    return {
        "preprocess_config": asdict(cfg),
        "kind_counts": kind_counts,
        "features": rows,
    }


# -----------------------------
# Dataset / Model
# -----------------------------

class PiecewiseTensorDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y = torch.from_numpy(y.astype(np.int64))

    def __len__(self) -> int:
        return int(self.y.shape[0])

    def __getitem__(self, idx: int):
        return self.X[idx], self.y[idx]


class PiecewiseFeatureEmbeddingModel(nn.Module):
    def __init__(
        self,
        num_bins: int,
        num_features: int,
        num_classes: int,
        d_embed: int = 64,
        lstm_hidden: int = 64,
        lstm_layers: int = 1,
        mha_heads: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_bins = int(num_bins)
        self.num_features = int(num_features)
        self.num_classes = int(num_classes)
        self.d_embed = int(d_embed)
        self.d_model = int(lstm_hidden) * 2

        self.bin_embedding = nn.Embedding(self.num_bins, d_embed)
        self.offset_projector = nn.Linear(1, d_embed)
        self.value_combiner = nn.Sequential(
            nn.Linear(2 * d_embed, d_embed),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_embed, d_embed),
        )
        self.feature_embeddings = nn.Parameter(torch.empty(num_features, d_embed))
        nn.init.normal_(self.feature_embeddings, mean=0.0, std=0.02)
        self.input_norm = nn.LayerNorm(d_embed)

        self.bilstm = nn.LSTM(
            input_size=d_embed,
            hidden_size=lstm_hidden,
            num_layers=lstm_layers,
            dropout=dropout if lstm_layers > 1 else 0.0,
            bidirectional=True,
            batch_first=True,
        )
        self.lstm_norm = nn.LayerNorm(self.d_model)
        self.mha = nn.MultiheadAttention(
            embed_dim=self.d_model,
            num_heads=mha_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.mha_norm = nn.LayerNorm(self.d_model)
        self.dropout = nn.Dropout(dropout)

        self.pool_query = nn.Parameter(torch.empty(self.d_model))
        nn.init.normal_(self.pool_query, mean=0.0, std=1.0 / math.sqrt(self.d_model))

        self.classifier = nn.Sequential(
            nn.LayerNorm(self.d_model),
            nn.Linear(self.d_model, self.d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(self.d_model, num_classes),
        )

    def make_tokens(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B,F,2]
        bin_ids = x[:, :, 0].long().clamp(0, self.num_bins - 1)
        offsets = x[:, :, 1].unsqueeze(-1)
        bin_emb = self.bin_embedding(bin_ids)
        offset_emb = self.offset_projector(offsets)
        v_value = self.value_combiner(torch.cat([bin_emb, offset_emb], dim=-1))
        v_feature = self.feature_embeddings.unsqueeze(0).expand(x.size(0), -1, -1)
        tokens = self.input_norm(v_value + v_feature)
        return tokens

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = self.make_tokens(x)
        h, _ = self.bilstm(tokens)
        h = self.lstm_norm(h)
        attn_out, _ = self.mha(h, h, h, need_weights=False)
        h = self.mha_norm(h + self.dropout(attn_out))

        scores = torch.matmul(h, self.pool_query) / math.sqrt(self.d_model)
        weights = torch.softmax(scores, dim=1).unsqueeze(-1)
        pooled = torch.sum(weights * h, dim=1)
        logits = self.classifier(pooled)
        return logits


# -----------------------------
# Train / eval
# -----------------------------

@torch.no_grad()
def evaluate(model: nn.Module, loader: DataLoader, device: torch.device, criterion: nn.Module) -> Dict[str, Any]:
    model.eval()
    total_loss = 0.0
    total_n = 0
    all_y: List[np.ndarray] = []
    all_pred: List[np.ndarray] = []
    for xb, yb in loader:
        xb = xb.to(device, non_blocking=True)
        yb = yb.to(device, non_blocking=True)
        logits = model(xb)
        loss = criterion(logits, yb)
        total_loss += float(loss.item()) * int(yb.size(0))
        total_n += int(yb.size(0))
        pred = torch.argmax(logits, dim=-1)
        all_y.append(yb.detach().cpu().numpy())
        all_pred.append(pred.detach().cpu().numpy())
    y = np.concatenate(all_y)
    pred = np.concatenate(all_pred)
    return {
        "loss": total_loss / max(total_n, 1),
        "acc": float(accuracy_score(y, pred)),
        "macro_f1": float(f1_score(y, pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y, pred, average="weighted", zero_division=0)),
        "y_true": y,
        "y_pred": pred,
    }


def train_main(args: argparse.Namespace) -> None:
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() or not args.device.startswith("cuda") else "cpu")

    out_root = Path(args.output_dir)
    run_dir = out_root / args.run_name
    ensure_dir(run_dir)

    dataset_npz = Path(args.dataset_npz)
    feature_names, y_train, y_val, label_names = load_feature_names_and_labels(dataset_npz)
    if label_names is None:
        label_names = [str(i) for i in sorted(np.unique(y_train).tolist())]

    train_raw = pd.read_csv(args.train_raw)
    val_raw = pd.read_csv(args.val_raw)

    fits, pcfg, clean_train, medians = fit_piecewise_preprocessor(
        train_raw,
        feature_names,
        num_quantiles=args.num_quantiles,
        skew_threshold=args.skew_threshold,
        z_clip=args.z_clip,
        clip_negative=not args.no_clip_negative,
    )
    X_train = transform_piecewise(train_raw, feature_names, fits, pcfg, medians)
    X_val = transform_piecewise(val_raw, feature_names, fits, pcfg, medians)

    prep_summary = summarize_preprocessing(X_train, X_val, fits, pcfg)
    save_json(prep_summary, run_dir / "piecewise_preprocess_summary.json")
    pd.DataFrame(prep_summary["features"]).to_csv(run_dir / "piecewise_feature_diag.csv", index=False)

    train_ds = PiecewiseTensorDataset(X_train, y_train)
    val_ds = PiecewiseTensorDataset(X_val, y_val)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    eval_train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    num_classes = int(max(np.max(y_train), np.max(y_val)) + 1)
    model = PiecewiseFeatureEmbeddingModel(
        num_bins=pcfg.num_bins,
        num_features=len(feature_names),
        num_classes=num_classes,
        d_embed=args.d_embed,
        lstm_hidden=args.lstm_hidden,
        lstm_layers=args.lstm_layers,
        mha_heads=args.mha_heads,
        dropout=args.dropout,
    ).to(device)

    criterion = nn.CrossEntropyLoss(label_smoothing=args.label_smoothing)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=args.lr * 0.05)

    config = vars(args).copy()
    config.update(
        {
            "num_features": len(feature_names),
            "num_classes": num_classes,
            "label_names": label_names,
            "preprocess_config": asdict(pcfg),
            "feature_kind_counts": prep_summary["kind_counts"],
            "model": "PiecewiseFeatureEmbedding + BiLSTM + MHA + attention pooling",
        }
    )
    save_json(config, run_dir / "config.json")

    best_val = -1.0
    best_epoch = -1
    best_payload: Dict[str, Any] = {}
    history_rows: List[Dict[str, Any]] = []
    start_time = time.time()

    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss = 0.0
        total_n = 0
        for xb, yb in train_loader:
            xb = xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            if args.grad_clip > 0:
                nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step()
            total_loss += float(loss.item()) * int(yb.size(0))
            total_n += int(yb.size(0))
        scheduler.step()

        train_eval = evaluate(model, eval_train_loader, device, criterion)
        val_eval = evaluate(model, val_loader, device, criterion)

        row = {
            "epoch": epoch,
            "train_loss_step": total_loss / max(total_n, 1),
            "train_loss": train_eval["loss"],
            "train_acc": train_eval["acc"],
            "train_macro_f1": train_eval["macro_f1"],
            "train_weighted_f1": train_eval["weighted_f1"],
            "val_loss": val_eval["loss"],
            "val_acc": val_eval["acc"],
            "val_macro_f1": val_eval["macro_f1"],
            "val_weighted_f1": val_eval["weighted_f1"],
            "lr": float(optimizer.param_groups[0]["lr"]),
            "elapsed_sec": float(time.time() - start_time),
        }
        history_rows.append(row)
        pd.DataFrame(history_rows).to_csv(run_dir / "history.csv", index=False)

        print(
            f"[epoch {epoch:03d}] "
            f"train_macro={row['train_macro_f1']:.6f} val_macro={row['val_macro_f1']:.6f} "
            f"train_loss={row['train_loss']:.6f} val_loss={row['val_loss']:.6f} "
            f"lr={row['lr']:.2e}",
            flush=True,
        )

        if row["val_macro_f1"] > best_val:
            best_val = row["val_macro_f1"]
            best_epoch = epoch
            torch.save({"model_state_dict": model.state_dict(), "config": config, "epoch": epoch}, run_dir / "best_model.pt")
            y_true = val_eval["y_true"]
            y_pred = val_eval["y_pred"]
            labels = list(range(num_classes))
            report = classification_report(
                y_true,
                y_pred,
                labels=labels,
                target_names=label_names[:num_classes],
                output_dict=True,
                zero_division=0,
            )
            cm = confusion_matrix(y_true, y_pred, labels=labels)
            save_json(report, run_dir / "val_classification_report_best.json")
            pd.DataFrame(cm, index=label_names[:num_classes], columns=label_names[:num_classes]).to_csv(run_dir / "val_confusion_matrix_best.csv")
            best_payload = {
                "best_epoch": best_epoch,
                "train_macro_f1": row["train_macro_f1"],
                "train_acc": row["train_acc"],
                "train_weighted_f1": row["train_weighted_f1"],
                "val_macro_f1": row["val_macro_f1"],
                "val_acc": row["val_acc"],
                "val_weighted_f1": row["val_weighted_f1"],
                "val_loss": row["val_loss"],
                "gap_train_val_macro_f1": row["train_macro_f1"] - row["val_macro_f1"],
                "malware_only_avg_f1": float(np.mean([report[label_names[i]]["f1-score"] for i in range(1, num_classes)])) if num_classes > 1 else None,
                "feature_kind_counts": prep_summary["kind_counts"],
            }
            save_json(best_payload, run_dir / "diagnosis_summary.json")

    if best_payload:
        print("\nBest:")
        print(json.dumps(best_payload, indent=2), flush=True)
    else:
        print("No best payload written", flush=True)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--train-raw", default="01_split/train_raw.csv")
    p.add_argument("--val-raw", default="01_split/val_raw.csv")
    p.add_argument("--dataset-npz", default="03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz")
    p.add_argument("--output-dir", default="03_outputs/train_runs_pfe_lstm_mha")
    p.add_argument("--run-name", required=True)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--num-quantiles", type=int, default=10)
    p.add_argument("--skew-threshold", type=float, default=1.0)
    p.add_argument("--z-clip", type=float, default=10.0)
    p.add_argument("--no-clip-negative", action="store_true")
    p.add_argument("--d-embed", type=int, default=64)
    p.add_argument("--lstm-hidden", type=int, default=64)
    p.add_argument("--lstm-layers", type=int, default=1)
    p.add_argument("--mha-heads", type=int, default=4)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--label-smoothing", type=float, default=0.0)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--num-workers", type=int, default=2)
    return p.parse_args()


if __name__ == "__main__":
    train_main(parse_args())
