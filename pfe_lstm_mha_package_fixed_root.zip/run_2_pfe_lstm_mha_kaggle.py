#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import subprocess
import time
import zipfile
from pathlib import Path

ROOT = Path('/kaggle/working/dacn')
LOG_DIR = ROOT / '03_outputs/parallel_logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)

SCRIPT = '02_src/25_train_pfe_lstm_mha.py'
DATASET = '03_outputs/build_mixed_quantile_offset/K512_B512_C2_selective_rank_discrete_compact/mixed_quantile_offset_dataset.npz'

RUNS = [
    {
        'name': 'PFE_Q10_faithful_LSTM_MHA',
        'device': 'cuda:0',
        'num_quantiles': '10',
        'note': 'faithful report setting NUM_QUANTILES=10 => NUM_BINS=13',
    },
    {
        'name': 'PFE_Q32_adapted_LSTM_MHA',
        'device': 'cuda:1',
        'num_quantiles': '32',
        'note': 'same architecture, higher quantile resolution for current MalMem data',
    },
]


def run_one(spec):
    log = LOG_DIR / f"{spec['name']}.log"
    cmd = [
        'python', '-u', SCRIPT,
        '--dataset-npz', DATASET,
        '--run-name', spec['name'],
        '--device', spec['device'],
        '--num-quantiles', spec['num_quantiles'],
        '--epochs', '80',
        '--batch-size', '256',
        '--d-embed', '64',
        '--lstm-hidden', '64',
        '--lstm-layers', '1',
        '--mha-heads', '4',
        '--dropout', '0.10',
        '--lr', '1e-3',
        '--weight-decay', '1e-4',
        '--grad-clip', '1.0',
    ]
    f = open(log, 'w')
    p = subprocess.Popen(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
    return p, f, log


def main():
    required = [ROOT / SCRIPT, ROOT / DATASET, ROOT / '01_split/train_raw.csv', ROOT / '01_split/val_raw.csv']
    for p in required:
        if not p.exists():
            raise FileNotFoundError(str(p))

    procs = []
    for spec in RUNS:
        p, f, log = run_one(spec)
        procs.append((spec, p, f, log))
        print(f"Started {spec['name']} pid={p.pid} device={spec['device']} log={log}")

    while True:
        done = True
        print('\n========== STATUS ==========', flush=True)
        for spec, p, f, log in procs:
            rc = p.poll()
            print(spec['name'], 'running' if rc is None else f'done rc={rc}', flush=True)
            if rc is None:
                done = False

        print('\n========== GPU ==========', flush=True)
        os.system('nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader')

        for spec, p, f, log in procs:
            print(f"\n========== {spec['name']} last 20 lines ==========", flush=True)
            os.system(f"tail -20 '{log}'")

        if done:
            break
        time.sleep(30)

    for spec, p, f, log in procs:
        f.close()

    out_zip = Path('/kaggle/working/pfe_lstm_mha_outputs.zip')
    items = []
    for spec in RUNS:
        run_dir = ROOT / '03_outputs/train_runs_pfe_lstm_mha' / spec['name']
        for fn in [
            'diagnosis_summary.json',
            'val_classification_report_best.json',
            'val_confusion_matrix_best.csv',
            'history.csv',
            'config.json',
            'piecewise_preprocess_summary.json',
            'piecewise_feature_diag.csv',
        ]:
            items.append(run_dir / fn)
        items.append(LOG_DIR / f"{spec['name']}.log")

    missing = []
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in items:
            if p.exists():
                z.write(p, str(p).replace('/kaggle/working/', ''))
            else:
                missing.append(str(p))

    print('\nWrote:', out_zip)
    print('Size:', out_zip.stat().st_size if out_zip.exists() else None)
    if missing:
        print('\nMissing:')
        for m in missing:
            print(m)
    else:
        print('\nAll files found.')


if __name__ == '__main__':
    main()
